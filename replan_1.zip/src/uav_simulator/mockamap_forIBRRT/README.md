# mockamap_IBRRT
a simple map generator based on ROS

demo cases:

* perlin3d map

![Alt text](https://github.com/HKUST-Aerial-Robotics/mockamap_IBRRT/blob/master/images/perlin3d.png)

* post2d map

![Alt text](https://github.com/HKUST-Aerial-Robotics/mockamap_IBRRT/blob/master/images/post2d.png)

@misc{mockamap_IBRRT,
  author = "William.Wu",
  title = "mockamap_IBRRT",
  howpublished = "\url{https://github.com/HKUST-Aerial-Robotics/mockamap_IBRRT }",
}
