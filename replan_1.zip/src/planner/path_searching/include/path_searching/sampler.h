/*
Copyright (C) 2022 Hongkai Ye (kyle_yeh@163.com)
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/
#ifndef _BIAS_SAMPLER_
#define _BIAS_SAMPLER_

#include <ros/ros.h>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Geometry>
#include <random>

class BiasSampler
{
public:
  BiasSampler()
  {
    std::random_device rd;
    gen_ = std::mt19937_64(rd());
    uniform_rand_ = std::uniform_real_distribution<double>(0.0, 1.0);//均匀采样
    normal_rand_ = std::normal_distribution<double>(0.0, 1.0);//正态高斯采样
    range_.setZero();
    origin_.setZero();
    informed_ = false;
  };
//设置原点，采样边界
  void setSamplingRange(const Eigen::Vector4d origin, const Eigen::Vector4d range)
  {
    origin_ = origin;
    range_ = range;
  }
//根据标志位informed_，GUILD_informed_是否有效采用informedSamplingOnce
//或者GUILDSamplingOnce或者均无效时全局地图采样uniformSamplingOnce
  void samplingOnce(Eigen::Vector4d &sample)
  {
    if(informed_)
      informedSamplingOnce(sample);
    else
      uniformSamplingOnce(sample);
  }
//uniform_real_distribution采样0~1后再矩阵数乘range_.array()地图上下边界
//，再+=origin_原点实现需要的空间采样
  void uniformSamplingOnce(Eigen::Vector4d &sample)
  {
    sample[0] = uniform_rand_(gen_);
    sample[1] = uniform_rand_(gen_);
    sample[2] = uniform_rand_(gen_);
    sample[3] = uniform_rand_(gen_);
    sample.array() *= range_.array();
    sample += origin_;
  };
//在radii_，rotation_，center_指定的椭球类随机采样，见main.cpp
  void informedSamplingOnce(Eigen::Vector4d &sample)
  {
    // random uniform sampling in a unit 4-ball
    Eigen::Vector4d p;
    p[0] = normal_rand_(gen_);//p[i]此时是均值为0，方差为1的高斯分布,偏向于椭球体的中心采样。高斯分布特性
    p[1] = normal_rand_(gen_);
    p[2] = normal_rand_(gen_);
    p[3] = normal_rand_(gen_);

    double r = pow(uniform_rand_(gen_), 1/4.0);//r为缩放比例因子
    sample = r * p.normalized();//限制在单位球中p.normalized();

    // transform the pt into the ellipsoid
    sample.array() *= radii_.array();//abc三轴缩放
    sample = rotation_ * sample;//旋转
    sample += center_;//平移
  }
//设置椭球几何中心center_=trans，旋转矩阵rotation_=rot
  void setInformedTransRot(const Eigen::Vector4d &trans, const Eigen::Matrix4d &rot)
  {
    center_ = trans;
    rotation_ = rot;
  }
//设置informed_=true,设置椭球radii_三轴长abc为scale,第四维缩放因子
  void setInformedSacling(const Eigen::Vector4d &scale)
  {
    informed_ = true;
    radii_ = scale;
  }

  void reset()
  {
    informed_ = false;
  }

  // (0.0 - 1.0)
  double getUniRandNum()
  {
    return uniform_rand_(gen_);
  }

private:
  Eigen::Vector4d range_, origin_;//原点，上下界
  std::mt19937_64 gen_;
  std::uniform_real_distribution<double> uniform_rand_;//均匀采样
  std::normal_distribution<double> normal_rand_;//正态高斯采样

  // for informed sampling
  bool informed_;
  Eigen::Vector4d center_, radii_;//椭球几何中心，椭球abc三轴，缩放scale
  Eigen::Matrix4d rotation_;//椭球旋转矩阵
};

#endif
