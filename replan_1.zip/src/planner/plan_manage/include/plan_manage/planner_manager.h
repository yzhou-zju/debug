/***
 * @Author: ztr
 * @Date: 2022-05-12 00:00:56
 * @LastEditTime: 2022-05-12 21:17:11
 * @LastEditors: ztr
 * @Description:
 * @FilePath: /Pipline-Swarm-Formation/src/planner/plan_manage/include/plan_manage/planner_manager.h
 */
#pragma once

#include <stdlib.h>
#include <ros/ros.h>
#include <plan_env/grid_map.h>
#include <path_searching/topo_prm.h>
#include <traj_utils/DataDisp.h>
#include <traj_utils/plan_container.hpp>
#include <traj_utils/planning_visualization.h>
#include <optimizer/poly_traj_utils.hpp>
#include <optimizer/poly_traj_optimizer.h>
#include <path_searching/align_assign.hpp>
#include <fstream>
#include <nav_msgs/Odometry.h>
#include "traj_utils/GlbObsRcv.h"
#include "path_searching/visualization.hpp"
#include "path_searching/form_rrt_star.h"
#include "path_searching/form_brrt_hybe.h"
#include <geometry_msgs/PoseStamped.h>
#include <eigen3/Eigen/Core>
#include <Eigen/StdVector>
namespace ego_planner
{

    // Fast Planner Manager
    // Key algorithms of mapping and planning are called

    class EGOPlannerManager
    {
        // SECTION stable
    public:
        volatile bool IBRRT_success{false}; // 等待IBRRT成功，状态机标志位
        std::ofstream log_ztr;              // for data analysis,ztr debug
        ros::Subscriber odom_sub;           // local plan
        nav_msgs::Odometry odom;
        void odom_cmb(const nav_msgs::OdometryConstPtr &msg) {odom = *msg; }

        bool last_kino_success;

        EGOPlannerManager();
        ~EGOPlannerManager();

        EIGEN_MAKE_ALIGNED_OPERATOR_NEW

        /* main planning interface */
        bool reboundReplan(
            const Eigen::Vector3d &start_pt, const Eigen::Vector3d &start_vel,
            const Eigen::Vector3d &start_acc, const double trajectory_start_time,
            const Eigen::Vector3d &end_pt, const Eigen::Vector3d &end_vel,
            const bool flag_polyInit, const bool use_formation, const bool have_local_traj);
        bool topoReboundReplan(
            const Eigen::Vector3d &start_pt, const Eigen::Vector3d &start_vel,
            const Eigen::Vector3d &start_acc, const Eigen::Vector3d &end_pt,
            const Eigen::Vector3d &end_vel, const bool flag_polyInit, const bool use_formation);
        bool computeInitState(
            const Eigen::Vector3d &start_pt, const Eigen::Vector3d &start_vel,
            const Eigen::Vector3d &start_acc, const Eigen::Vector3d &local_target_pt,
            const Eigen::Vector3d &local_target_vel, const bool flag_polyInit,
            const bool flag_randomPolyTraj, const double &ts, poly_traj::MinJerkOpt &initMJO);
        bool computeInitReferenceState(
            const Eigen::Vector3d &start_pt, const Eigen::Vector3d &start_vel,
            const Eigen::Vector3d &start_acc, const Eigen::Vector3d &local_target_pt,
            const Eigen::Vector3d &local_target_vel, const double &ts, poly_traj::MinJerkOpt &initMJO,
            const bool flag_polyInit);
        bool planGlobalTrajWaypoints(
            const Eigen::Vector3d &start_pos, const Eigen::Vector3d &start_vel,
            const Eigen::Vector3d &start_acc, const std::vector<Eigen::Vector3d> &waypoints,
            const Eigen::Vector3d &end_vel, const Eigen::Vector3d &end_acc);
        bool planGlobalTrajReMap(
            const Eigen::Vector3d &start_pos, const Eigen::Vector3d &start_vel, const Eigen::Vector3d &start_acc,
            const Eigen::Vector3d &remap_lg_pos, const Eigen::Vector3d &remap_lg_vel, const Eigen::Vector3d &remap_lg_acc,
            const std::vector<Eigen::Vector3d> &wps, const Eigen::Vector3d &end_vel, const Eigen::Vector3d &end_acc);
        bool planSwarmGlobalPath(
            const Eigen::Vector3d &start_pos, const Eigen::Vector3d &goal_pos, const double &swarm_scale,
            std::vector<Eigen::Vector4d> &swarm_global_path);
        void getLocalTarget(
            const double planning_horizen, const Eigen::Vector3d &start_pt,
            const Eigen::Vector3d &global_end_pt, Eigen::Vector3d &local_target_pos,
            Eigen::Vector3d &local_target_vel);
        void getLocalTargetHorizenTime(
            const double planning_horizen_time,
            const Eigen::Vector3d &start_pt, const Eigen::Vector3d &global_end_pt,
            Eigen::Vector3d &local_target_pos, Eigen::Vector3d &local_target_vel);

        void callAlignAssign(const std::vector<Eigen::Vector3d> &nodes_horizon, const std::vector<Eigen::Vector3d> &nodes_cur,
                             const Eigen::VectorXd &aware_weight, std::vector<Eigen::Vector3d> &opt_goals,
                             Eigen::VectorXi &opt_assignment);

        void initPlanModules(ros::NodeHandle &nh, PlanningVisualization::Ptr vis = NULL);
        void rrt_replan(ros::NodeHandle &nh);
        bool EmergencyStop(Eigen::Vector3d stop_pos);
        void deliverTrajToOptimizer(void) { ploy_traj_opt_->setSwarmTrajs(&traj_.swarm_traj); };
        void setDroneIdtoOpt(void) { ploy_traj_opt_->setDroneId(pp_.drone_id); }
        double getSwarmClearance(void) { return ploy_traj_opt_->getSwarmClearance(); }
        bool checkCollision(int drone_id);
        void fakeSwarmTrajs(void);
        double getFormationError(double t, Eigen::Vector3d pos);
        std::vector<Eigen::Vector3d> getFormationCurrentPos(double t, Eigen::Vector3d pos);
        void getFormationPosAndVel(double t, double delta_t,
                                   vector<Eigen::Vector3d> &swarm_graph_pos,
                                   vector<Eigen::Vector3d> &swarm_graph_vel);

        // topo
        bool topoPathPlanning(
            const Eigen::Vector3d &start_pt, const Eigen::Vector3d &start_vel,
            const Eigen::Vector3d &start_acc, const Eigen::Vector3d &end_pt,
            const Eigen::Vector3d &end_vel, std::vector<std::vector<Eigen::Vector3d>> &select_paths);

        bool findCollisionRange(
            vector<Eigen::Vector3d> &colli_start, vector<Eigen::Vector3d> &colli_end,
            vector<Eigen::Vector3d> &start_pts, vector<Eigen::Vector3d> &end_pts,
            poly_traj::MinJerkOpt &initMJO);

        PlanParameters pp_;

        TrajContainer traj_;
        unique_ptr<TopologyPRM> topo_prm_;
        PolyTrajOptimizer::Ptr ploy_traj_opt_;
        AlignAssign align_assign_;

        bool start_flag_, reach_flag_;
        ros::Time global_start_time_;
        double start_time_, reach_time_, average_plan_time_;

        // for IBRRT
        void executionCallback(const ros::TimerEvent &event)
        {
            std::cout<<"executionCallback"<<std::endl;
            ROS_WARN_STREAM("[planner manager]--------------------in executionCallback-------------");
            // log_ztr << "--------------------------------in executionCallback--------------------------------" << endl;
            if (!have_map_)
            {
                ROS_WARN_STREAM("[planner manager]--------------------have_no__map_-------------");
                //  log_ztr << "--------------------------------have_no__map_--------------------------------" << endl;
                ROS_INFO("no map rcved yet.");
                traj_utils::GlbObsRcv srv;
                if (!rcv_glb_obs_client_.call(srv))
                    ROS_WARN("Failed to call service /pub_glb_obs");
                else
                    have_map_ = true;
            }
            else
                execution_timer_.stop();
        }

        void planTriggerCallback(const ros::TimerEvent &event)
        {
            std::cout<<"planTriggerCallback"<<std::endl;
            ROS_WARN_STREAM("[planner manager]--------------------in planTriggerCallback-------------");
            // log_ztr << "--------------------------------in planTriggerCallback--------------------------------" << endl;
            // log_ztr<<" IBRRT????success???"<<IBRRT_success<<endl;
            static int success = 0; // ztr
            // static ros::Time::now();
            if (have_map_)
            {
                ROS_WARN_STREAM("[planner manager]----------------have map and start to plan-------------");
                ros::Duration(0.1).sleep();
                vis_ptr_->visualize_a_ball(start_, 0.2, "start", visualization::Color::pink);
                vis_ptr_->visualize_a_ball(goal_, 0.2, "goal", visualization::Color::steelblue);
                if (run_rrt_star_)
                {
                    ROS_WARN_STREAM("[planTriggerCallback]------------------start in plan------------------------");
                    bool rrt_star_res = form_rrt_star_ptr_->plan(start_, goal_);
                    ROS_WARN_STREAM("[planTriggerCallback]------------------end in plan------------------------");
                    // log_ztr << "rrt_star_res----------------------" << rrt_star_res << endl;
                    // ztr
                    if (rrt_star_res)
                    {
                        success++;
                        IBRRT_success = true;
                    }
                    // 等待这部分成功后再进入状态机执行其余剩下步骤
                    if (success >= 1)
                    {
                        IBRRT_success = true;
                        plan_trigger_timer_.stop();
                    }
                }

                if (run_brrt_hybe_)
                {
                    ROS_WARN_STREAM("[planTriggerCallback]------------------start in plan------------------------");
                    bool brrt_hybe_res = form_brrt_hybe_ptr_->plan(start_, goal_);
                    ROS_WARN_STREAM("[planTriggerCallback]------------------end in plan------------------------");
                    // log_ztr << "brrt_hybe_res----------------------" << brrt_hybe_res << endl;
                    // ztr
                    if (brrt_hybe_res)
                    {
                        success++;
                        IBRRT_success = true;
                    }
                    // 等待这部分成功后再进入状态机执行其余剩下步骤
                    if (success >= 2)
                    {
                        wps_from_IBRRT = form_brrt_hybe_ptr_->getPath();
                        IBRRT_success = true;
                        plan_trigger_timer_.stop();
                    }
                }
            }
        }

    private:
        /* main planning algorithms & modules */
        PlanningVisualization::Ptr visualization_;
        bool use_kino;
        int continous_failures_count_{0};

        // for IBRRT

        vector<Eigen::Vector4d> wps_from_IBRRT;
        ros::NodeHandle nh_;
        double startx, starty, startz, startscale;
        double endx, endy, endz, endscale;
        // ros::NodeHandle nh_;
        // GridMap::Ptr grid_map_;

        ros::Timer execution_timer_;
        ros::ServiceClient rcv_glb_obs_client_;
        std::shared_ptr<visualization::Visualization> vis_ptr_;
        shared_ptr<path_plan::FormRRTStar> form_rrt_star_ptr_;
        shared_ptr<path_plan::FormBRRTHybe> form_brrt_hybe_ptr_;

        ros::Timer plan_trigger_timer_;
        Eigen::Vector4d start_, goal_;
        bool have_map_;

        bool run_brrt_hybe_, run_rrt_star_;

    public:
        typedef unique_ptr<EGOPlannerManager> Ptr;
        GridMap::Ptr grid_map_;

        // !SECTION
    };
} // namespace ego_planner