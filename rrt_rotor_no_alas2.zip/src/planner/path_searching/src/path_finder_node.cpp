#include "traj_utils/GlbObsRcv.h"
#include "path_searching/visualization.hpp"
#include "plan_env/grid_map.h"
#include "path_searching/form_rrt_star.h"
#include "path_searching/form_brrt_hybe.h"
#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <eigen3/Eigen/Core>
#include <Eigen/StdVector>

class FormPlanner
{
private:
double startx,starty,startz,startscale;
double endx,endy,endz,endscale;
    ros::NodeHandle nh_;
    GridMap::Ptr grid_map_;

    ros::Timer execution_timer_;
    ros::ServiceClient rcv_glb_obs_client_;
    std::shared_ptr<visualization::Visualization> vis_ptr_;
    shared_ptr<path_plan::FormRRTStar> form_rrt_star_ptr_;
    shared_ptr<path_plan::FormBRRTHybe> form_brrt_hybe_ptr_;

    ros::Timer plan_trigger_timer_;
    Eigen::Vector4d start_, goal_;
    bool have_map_;

    bool run_brrt_hybe_, run_rrt_star_;

public:
    FormPlanner(const ros::NodeHandle &nh) : nh_(nh)
    {
        vector<Eigen::Vector3d> des_form;
        des_form.emplace_back(0, 0, 0);
        des_form.emplace_back(1.7321, -1, 0);
        des_form.emplace_back(0, -2, 0);
        des_form.emplace_back(-1.7321, -1, 0);
        des_form.emplace_back(-1.7321, 1, 0);
        des_form.emplace_back(0, 2, 0);
        des_form.emplace_back(1.7321, 1, 0);

        // start_ << -10, 11, 1.5, 1.5;
        // goal_ << 7, 11, 1.5, 1.5;

        grid_map_.reset(new GridMap);
        grid_map_->initMap(nh_);
        have_map_ = false;

        vis_ptr_ = std::make_shared<visualization::Visualization>(nh_);

        form_rrt_star_ptr_.reset(new path_plan::FormRRTStar(nh_, grid_map_, des_form));
        form_rrt_star_ptr_->setVisualizer(vis_ptr_);
        
        form_brrt_hybe_ptr_.reset(new path_plan::FormBRRTHybe(nh_, grid_map_, des_form));
        form_brrt_hybe_ptr_->setVisualizer(vis_ptr_);

        execution_timer_ = nh_.createTimer(ros::Duration(1), &FormPlanner::executionCallback, this);
        rcv_glb_obs_client_ = nh_.serviceClient<traj_utils::GlbObsRcv>("/pub_glb_obs");

        plan_trigger_timer_ = nh_.createTimer(ros::Duration(2), &FormPlanner::planTriggerCallback, this);

        nh_.param("run_rrt_star", run_rrt_star_, false);
        nh_.param("run_brrt_hybe", run_brrt_hybe_, false);
        nh_.param("startx", startx, 15.0);
        nh_.param("starty", starty, 20.0);
        nh_.param("startz", startz, 1.0);
        nh_.param("startscale", startscale, 1.5);
        nh_.param("endx", endx, -20.0);
        nh_.param("endy", endy, 20.0);
        nh_.param("endz", endz, 1.0);
         nh_.param("endscale", endscale, 1.5);

        start_ << startx, starty, startz, startscale;
        goal_ << endx, endy, endz, endscale;
    }

    ~FormPlanner(){};
    
    void executionCallback(const ros::TimerEvent &event)
    {
        if (!have_map_)
        {
            ROS_INFO("no map rcved yet.");
            traj_utils::GlbObsRcv srv;
            if (!rcv_glb_obs_client_.call(srv))
                ROS_WARN("Failed to call service /pub_glb_obs");
            else
                have_map_ = true;
        }
        else
            execution_timer_.stop();
    }

    void planTriggerCallback(const ros::TimerEvent &event)
    {static int success=0;//ztr
        // static ros::Time::now();
        if (have_map_)
        {
            ros::Duration(0.1).sleep();
            vis_ptr_->visualize_a_ball(start_, 0.2, "start", visualization::Color::pink);
            vis_ptr_->visualize_a_ball(goal_, 0.2, "goal", visualization::Color::steelblue);
            if (run_rrt_star_)
            {
                bool rrt_star_res = form_rrt_star_ptr_->plan(start_, goal_);
                // ztr
                if (rrt_star_res)
                success++;
                if(success>=2)
                    plan_trigger_timer_.stop();
            }

            if (run_brrt_hybe_)
            {
                bool brrt_hybe_res = form_brrt_hybe_ptr_->plan(start_, goal_);
                // ztr
                if (brrt_hybe_res)
                 success++;
                if(success>=2)
                    plan_trigger_timer_.stop();
            }
        }
    }
};

int main(int argc, char **argv)
{
    ros::init(argc, argv, "path_finder_node");
    ros::NodeHandle nh("~");

    FormPlanner tester(nh);

    ros::AsyncSpinner spinner(0);
    spinner.start();
    ros::waitForShutdown();
    return 0;
}
