#ifndef RAYCAST4_H_
#define RAYCAST4_H_

#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Geometry>
#include <eigen3/Eigen/StdVector>
#include <vector>

class RayCaster4 {
private:
  /* data */
  Eigen::Vector4d start_;
  Eigen::Vector4d end_;
  Eigen::Vector4d direction_;
  Eigen::Vector4d min_;
  Eigen::Vector4d max_;
  int x_;
  int y_;
  int z_;
  int s_;

  int endX_;
  int endY_;
  int endZ_;
  int endS_;

  double maxDist_;
  double dx_;
  double dy_;
  double dz_;
  double ds_;

  int stepX_;
  int stepY_;
  int stepZ_;
  int stepS_;

  double tMaxX_;
  double tMaxY_;
  double tMaxZ_;
  double tMaxS_;

  double tDeltaX_;
  double tDeltaY_;
  double tDeltaZ_;
  double tDeltaS_;
  double dist_;

  int step_num_;

public:
  RayCaster4(/* args */) {}
  ~RayCaster4() {}

  int signum(int x);
  double mod(double value, double modulus);
  double intbound(double s, double ds);

  bool setInput(const Eigen::Vector4d& start,
                const Eigen::Vector4d& end);

  bool step(Eigen::Vector4d& ray_pt);
};

#endif  // RAYCAST4_H_