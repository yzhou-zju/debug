/*
Copyright (C) 2022 Hongkai Ye (kyle_yeh@163.com), Longji Yin (ljyin6038@163.com)
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/
#ifndef BRRT_HYBE_H
#define BRRT_HYBE_H

#include "plan_env/grid_map.h"
#include "visualization.hpp"
#include "sampler.h"
#include "node.h"
#include "kdtree.h"

#include <ros/ros.h>
#include <utility>
#include <queue>
#include <algorithm>

namespace path_plan
{
  class FormBRRTHybe
  {
  public:
    FormBRRTHybe(){};
    FormBRRTHybe(const ros::NodeHandle &nh, const GridMap::Ptr &mapPtr, const vector<Eigen::Vector3d> &des_form) : nh_(nh), map_ptr_(mapPtr), des_form_(des_form)
    {
      nh_.param("BRRT_Hybe/steer_length", steer_length_, 0.0);
      nh_.param("BRRT_Hybe/search_radius", search_radius_, 0.0);
      nh_.param("BRRT_Hybe/search_time", search_time_, 0.0);
      nh_.param("BRRT_Hybe/max_tree_node_nums", max_tree_node_nums_, 0);
      nh_.param("BRRT_Hybe/scale_weight", scale_weight_, 0.0);
      nh_.param("BRRT_Hybe/sampling_range_x", sampling_range_x_, 30.0);
      nh_.param("BRRT_Hybe/sampling_range_y", sampling_range_y_, 30.0);
      nh_.param("BRRT_Hybe/sampling_range_z", sampling_range_z_, 3.0);
      nh_.param("BRRT_Hybe/sampling_range_scale_min", sampling_range_scale_min_, 0.1);
      nh_.param("BRRT_Hybe/sampling_range_scale_max", sampling_range_scale_max_, 2.0);

      ROS_WARN_STREAM("[BRRT_Hybe] param: steer_length: " << steer_length_);
      ROS_WARN_STREAM("[BRRT_Hybe] param: sampling_range_scale_max: " << sampling_range_scale_max_);
      ROS_WARN_STREAM("[BRRT_Hybe] param: sampling_range_scale_min: " << sampling_range_scale_min_);
      ROS_WARN_STREAM("[BRRT_Hybe] param: sampling_range_x: " << sampling_range_x_);
      ROS_WARN_STREAM("[BRRT_Hybe] param: sampling_range_y: " << sampling_range_y_);
      ROS_WARN_STREAM("[BRRT_Hybe] param: sampling_range_z: " << sampling_range_z_);
      ROS_WARN_STREAM("[BRRT_Hybe] param: scale_weight: " << scale_weight_);
      ROS_WARN_STREAM("[BRRT_Hybe] param: search_radius: " << search_radius_);
      ROS_WARN_STREAM("[BRRT_Hybe] param: search_time: " << search_time_);
      ROS_WARN_STREAM("[BRRT_Hybe] param: max_tree_node_nums: " << max_tree_node_nums_);

      // Set sampling range
      weight_vec_ << 1.0, 1.0, 1.0, scale_weight_;
      weight_inv_ << 1.0, 1.0, 1.0, 1.0 / scale_weight_;
      Eigen::Vector4d sampling_origin(-sampling_range_x_ / 2, -sampling_range_y_ / 2, 0.0, sampling_range_scale_min_);
      Eigen::Vector4d sampling_range(sampling_range_x_, sampling_range_y_, sampling_range_z_, (sampling_range_scale_max_ - sampling_range_scale_min_));
      sampler_.setSamplingRange(sampling_origin.cwiseProduct(weight_vec_), sampling_range.cwiseProduct(weight_vec_));

      valid_tree_node_nums_ = 0;
      nodes_pool_.resize(max_tree_node_nums_);
      for (int i = 0; i < max_tree_node_nums_; ++i)
      {
        nodes_pool_[i] = new TreeNode;
      }
    }
    ~FormBRRTHybe(){};

    bool plan(const Eigen::Vector4d &s, const Eigen::Vector4d &g)
    {
      ROS_WARN_STREAM("-------------------------in plan--------------------  ");
      reset();
      Eigen::Vector4d start = toSpace(s);
      Eigen::Vector4d goal = toSpace(g);

      if (!map_ptr_->isLeaderCollisionFree(s, des_form_, true))
      {
        ROS_WARN_STREAM("[BRRT_Hybe]: Start pos collide or out of bound");
        ROS_ERROR("[BRRT_Hybe]: Start pos collide or out of bound");
        return false;
      }

      if (!map_ptr_->isLeaderCollisionFree(g, des_form_, true))
      {
        ROS_WARN_STREAM("[BRRT_Hybe]: Goal pos collide or out of bound");
        ROS_ERROR("[BRRT_Hybe]: Goal pos collide or out of bound");
        return false;
      }
      /* construct start and goal nodes */
      start_node_ = nodes_pool_[1];
      start_node_->x = start;
      start_node_->cost_from_start = 0.0;
      goal_node_ = nodes_pool_[0];
      goal_node_->x = goal;
      goal_node_->cost_from_start = 0.0; // important
      valid_tree_node_nums_ = 2;
      // put start and goal in tree
      ROS_WARN_STREAM("[BRRT_Hybe]: BRRT_hybe starts planning a path");
      ROS_INFO("[BRRT_Hybe]: BRRT_hybe starts planning a path");

      /* Init the sampler for informed sampling */
      sampler_.reset();
      calInformedSet(10000000000.0, start, goal, scale_, trans_, rot_);
      sampler_.setInformedTransRot(trans_, rot_);
      return brrt_hybe(start, goal);
    }

    vector<Eigen::Vector4d> getPath()
    {
      auto real_path = final_path_;
      for (size_t i = 0; i < final_path_.size(); i++)
      {
        real_path[i][3] /= scale_weight_;
      }

      return real_path;
      // return final_path_;
    }

    vector<Eigen::Vector4d> getFirstPath()
    {
      return first_path_;
    }

    vector<vector<Eigen::Vector4d>> getAllPaths()
    {
      return path_list_;
    }

    vector<std::pair<double, double>> getSolutions()
    {
      return solution_cost_time_pair_list_;
    }

    void setVisualizer(const std::shared_ptr<visualization::Visualization> &visPtr)
    {
      vis_ptr_ = visPtr;
    };

  private:
    // nodehandle params
    ros::NodeHandle nh_;

    BiasSampler sampler_;
    // for informed sampling
    Eigen::Vector4d trans_, scale_;
    Eigen::Matrix4d rot_;

    double steer_length_;
    double search_radius_;
    double search_time_;
    int max_tree_node_nums_;
    int valid_tree_node_nums_;
    double first_path_use_time_;
    double final_path_use_time_;

    // Scale Weight
    double scale_weight_;
    Eigen::Vector4d weight_vec_;
    Eigen::Vector4d weight_inv_;

    // Sampling Range
    double sampling_range_x_, sampling_range_y_, sampling_range_z_;
    double sampling_range_scale_min_, sampling_range_scale_max_;

    // Formation template
    vector<Eigen::Vector3d> des_form_;

    // for bidirectional sampling
    double cost_best_;

    std::vector<TreeNode *> nodes_pool_;
    TreeNode *start_node_;
    TreeNode *goal_node_;
    vector<Eigen::Vector4d> final_path_;
    vector<Eigen::Vector4d> first_path_;
    vector<vector<Eigen::Vector4d>> path_list_;
    vector<std::pair<double, double>> solution_cost_time_pair_list_;

    // environment
    GridMap::Ptr map_ptr_;
    std::shared_ptr<visualization::Visualization> vis_ptr_;

    void reset()
    {
      final_path_.clear();
      first_path_.clear();
      path_list_.clear();
      cost_best_ = DBL_MAX;
      solution_cost_time_pair_list_.clear();

      for (int i = 0; i < valid_tree_node_nums_; i++)
      {
        nodes_pool_[i]->parent = nullptr;
        nodes_pool_[i]->children.clear();
      }
      valid_tree_node_nums_ = 0;
    }

    double calDist(const Eigen::Vector4d &p1, const Eigen::Vector4d &p2)
    {
      return (p1 - p2).norm();
    }

    RRTNode4DPtr addTreeNode(RRTNode4DPtr &parent, const Eigen::Vector4d &state,
                             const double &cost_from_start, const double &cost_from_parent)
    {
      RRTNode4DPtr new_node_ptr = nodes_pool_[valid_tree_node_nums_];
      valid_tree_node_nums_++;
      new_node_ptr->parent = parent;
      parent->children.push_back(new_node_ptr);
      new_node_ptr->x = state;
      new_node_ptr->cost_from_start = cost_from_start;
      new_node_ptr->cost_from_parent = cost_from_parent;
      return new_node_ptr;
    }

    void changeNodeParent(RRTNode4DPtr &node, RRTNode4DPtr &parent, const double &cost_from_parent)
    {
      if (node->parent)
        node->parent->children.remove(node); // DON'T FORGET THIS, remove it form its parent's children list
      node->parent = parent;
      node->cost_from_parent = cost_from_parent;
      node->cost_from_start = parent->cost_from_start + cost_from_parent;
      parent->children.push_back(node);

      // for all its descedants, change the cost_from_start and tau_from_start;
      RRTNode4DPtr descendant(node);
      std::queue<RRTNode4DPtr> Q;
      Q.push(descendant);
      while (!Q.empty())
      {
        descendant = Q.front();
        Q.pop();
        for (const auto &leafptr : descendant->children)
        {
          leafptr->cost_from_start = leafptr->cost_from_parent + descendant->cost_from_start;
          Q.push(leafptr);
        }
      }
    }

    bool connectSteer(const Eigen::Vector4d &x_near, const Eigen::Vector4d &x_target, vector<Eigen::Vector4d> &x_connects, const double len)
    {
      double vec_length = (x_target - x_near).norm();
      Eigen::Vector4d vec_unit = (x_target - x_near) / vec_length;
      x_connects.clear();

      if (vec_length < len)
        return map_ptr_->isSegCollisionFree(toMap(x_near), toMap(x_target), des_form_) ? true : false;

      Eigen::Vector4d x_new, x_pre = x_near;
      double steered_dist = 0;

      while (steered_dist + len < vec_length)
      {
        x_new = x_pre + len * vec_unit;
        if ((!map_ptr_->isLeaderCollisionFree(toMap(x_new), des_form_, false)) || (!map_ptr_->isSegCollisionFree(toMap(x_new), toMap(x_pre), des_form_)))
          return false;

        x_pre = x_new;
        x_connects.push_back(x_new);
        steered_dist += len;
      }
      return map_ptr_->isSegCollisionFree(toMap(x_target), toMap(x_pre), des_form_) ? true : false;
    }

    Eigen::Vector4d steer(const Eigen::Vector4d &nearest_node_p, const Eigen::Vector4d &rand_node_p, double len)
    {
      Eigen::Vector4d diff_vec = rand_node_p - nearest_node_p;
      double dist = diff_vec.norm();
      if (diff_vec.norm() <= len)
        return rand_node_p;
      else
        return nearest_node_p + diff_vec * len / dist;
    }

    void fillPath(const RRTNode4DPtr &node_A, const RRTNode4DPtr &node_B, vector<Eigen::Vector4d> &path)
    {
      path.clear();
      RRTNode4DPtr node_ptr = node_A;
      while (node_ptr->parent)
      {
        path.push_back(node_ptr->x);
        node_ptr = node_ptr->parent;
      }
      path.push_back(start_node_->x);
      std::reverse(std::begin(path), std::end(path));

      node_ptr = node_B;
      while (node_ptr->parent)
      {
        path.push_back(node_ptr->x);
        node_ptr = node_ptr->parent;
      }
      path.push_back(goal_node_->x);
    }

    void sortNbrSet(Neighbour &nbrSet, Eigen::Vector4d &x_rand)
    {
      std::sort(nbrSet.nearing_nodes.begin(), nbrSet.nearing_nodes.end(),
                [&x_rand](NodeWithStatus &node1, NodeWithStatus &node2)
                {
                  return node1.node_ptr->cost_from_start + (node1.node_ptr->x - x_rand).norm() <
                         node2.node_ptr->cost_from_start + (node2.node_ptr->x - x_rand).norm();
                });
    }

    void rewireTree(Neighbour &nbrSet, RRTNode4DPtr &new_node, const Eigen::Vector4d &x_target)
    {
      for (auto curr_node : nbrSet.nearing_nodes)
      {
        double dist_to_potential_child = calDist(new_node->x, curr_node.node_ptr->x);
        bool not_consistent = new_node->cost_from_start + dist_to_potential_child < curr_node.node_ptr->cost_from_start ? true : false;
        bool promising = new_node->cost_from_start + dist_to_potential_child + calDist(curr_node.node_ptr->x, x_target) < cost_best_ ? true : false;
        // For rewire rejection
        if (not_consistent && promising)
        {
          bool connected(false);
          if (curr_node.is_checked)
            connected = curr_node.is_valid;
          else
            connected = map_ptr_->isSegCollisionFree(toMap(new_node->x), toMap(curr_node.node_ptr->x), des_form_);

          if (connected)
            changeNodeParent(curr_node.node_ptr, new_node, dist_to_potential_child);
        }
      }
    }

    bool brrt_hybe(const Eigen::Vector4d &s, const Eigen::Vector4d &g)
    {
      ros::Time rrt_start_time = ros::Time::now();
      bool tree_connected = false;
      bool path_reverse = false;
      double c_square = (g - s).squaredNorm() / 4.0;

      /* kd tree init */
      kdtree *kdtree_1 = kd_create(4);
      kdtree *kdtree_2 = kd_create(4);
      // Add start and goal nodes to kd trees
      kd_insert4(kdtree_1, start_node_->x[0], start_node_->x[1], start_node_->x[2], start_node_->x[3], start_node_);
      kd_insert4(kdtree_2, goal_node_->x[0], goal_node_->x[1], goal_node_->x[2], goal_node_->x[3], goal_node_);

      kdtree *treeA = kdtree_1;
      kdtree *treeB = kdtree_2;

      /* main loop */
      int idx = 0;

      for (idx = 0; (ros::Time::now() - rrt_start_time).toSec() < search_time_ && valid_tree_node_nums_ < max_tree_node_nums_; ++idx)
      {
        /* random sampling */
        Eigen::Vector4d x_rand;
        sampler_.samplingOnce(x_rand);

        // samplingOnce(x_rand);
        if (!map_ptr_->isLeaderCollisionFree(toMap(x_rand), des_form_, false))
        {
          continue;
        }

        if (!tree_connected)
        {
          /* Goal not found yet, conduct simple brrt */
          struct kdres *p_nearestA = kd_nearest4(treeA, x_rand[0], x_rand[1], x_rand[2], x_rand[3]);
          if (p_nearestA == nullptr)
          {
            ROS_ERROR("nearest query error");
            continue;
          }
          RRTNode4DPtr nearest_nodeA = (RRTNode4DPtr)kd_res_item_data(p_nearestA);
          kd_res_free(p_nearestA);

          /* Extend treeA */
          Eigen::Vector4d x_new = steer(nearest_nodeA->x, x_rand, steer_length_);
          if ((!map_ptr_->isLeaderCollisionFree(toMap(x_new), des_form_, false)) || (!map_ptr_->isSegCollisionFree(toMap(nearest_nodeA->x), toMap(x_new), des_form_)))
          {
            /* Steer Trapped */
            std::swap(treeA, treeB);
            path_reverse = !path_reverse;
            continue;
          }

          /* Add x_new to treeA */
          double dist_from_A = nearest_nodeA->cost_from_start + steer_length_;
          RRTNode4DPtr new_nodeA(nullptr);
          new_nodeA = addTreeNode(nearest_nodeA, x_new, dist_from_A, steer_length_);
          kd_insert4(treeA, x_new[0], x_new[1], x_new[2], x_new[3], new_nodeA);

          /* Get x_new's nearest node in treeB */
          struct kdres *p_nearestB = kd_nearest4(treeB, x_new[0], x_new[1], x_new[2], x_new[3]);
          if (p_nearestB == nullptr)
          {
            ROS_ERROR("nearest query error");
            continue;
          }
          RRTNode4DPtr nearest_nodeB = (RRTNode4DPtr)kd_res_item_data(p_nearestB);
          kd_res_free(p_nearestB);

          /* Greedy steer to check connection */
          vector<Eigen::Vector4d> x_connects;
          bool isConnected = connectSteer(nearest_nodeB->x, x_new, x_connects, steer_length_);

          /* Add the steered nodes to treeB */
          RRTNode4DPtr new_nodeB = nearest_nodeB;
          if (!x_connects.empty())
          {
            if (valid_tree_node_nums_ + (int)x_connects.size() >= max_tree_node_nums_)
            {
              valid_tree_node_nums_ += x_connects.size();
              break;
            } // max_tree_node_nums_ reached

            for (auto x_connect : x_connects)
            {
              new_nodeB = addTreeNode(new_nodeB, x_connect, new_nodeB->cost_from_start + steer_length_, steer_length_);
              kd_insert4(treeB, x_connect[0], x_connect[1], x_connect[2], x_connect[3], new_nodeB);
            }
          }

          if (isConnected)
          {
            /* Trace the path */
            vector<Eigen::Vector4d> curr_best_path;
            if (path_reverse)
              fillPath(new_nodeB, new_nodeA, curr_best_path);
            else
              fillPath(new_nodeA, new_nodeB, curr_best_path);
            path_list_.emplace_back(curr_best_path);
            cost_best_ = new_nodeA->cost_from_start + new_nodeB->cost_from_start + calDist(new_nodeB->x, new_nodeA->x);
            solution_cost_time_pair_list_.emplace_back(cost_best_, (ros::Time::now() - rrt_start_time).toSec());

            tree_connected = true; // Goal found
            treeA = kdtree_1;
            treeB = kdtree_2; // Fix treeA & B with initial order
            /* Set informed sampling set */
            scale_[0] = cost_best_ / 2.0;
            scale_[1] = sqrt(scale_[0] * scale_[0] - c_square);
            scale_[3] = scale_[2] = scale_[1];
            sampler_.setInformedSacling(scale_);

            continue;
          }

          std::swap(treeA, treeB);
          path_reverse = !path_reverse;
          /* End of brrt */
        }
        else
        {

          /* Goal found, conduct informed brrt_star */
          bool check_connect = false;
          bool isTreeA = true;

          /* Search neighbors in both treeA and treeB */
          Neighbour neighbour_nodesA, neighbour_nodesB;
          neighbour_nodesA.nearing_nodes.reserve(80);
          neighbour_nodesB.nearing_nodes.reserve(80);
          neighbour_nodesB.center = neighbour_nodesA.center = x_rand;
          struct kdres *nbr_setA = kd_nearest_range4(treeA, x_rand[0], x_rand[1], x_rand[2], x_rand[3], search_radius_);
          struct kdres *nbr_setB = kd_nearest_range4(treeB, x_rand[0], x_rand[1], x_rand[2], x_rand[3], search_radius_);

          if (nbr_setA == nullptr) // TreeA
          {
            struct kdres *p_nearest = kd_nearest4(treeA, x_rand[0], x_rand[1], x_rand[2], x_rand[3]);
            if (p_nearest == nullptr)
            {
              ROS_ERROR("nearest query error");
              continue;
            }
            RRTNode4DPtr nearest_node = (RRTNode4DPtr)kd_res_item_data(p_nearest);
            kd_res_free(p_nearest);
            neighbour_nodesA.nearing_nodes.emplace_back(nearest_node, false, false);
          }
          else
          {
            check_connect = true;
            while (!kd_res_end(nbr_setA))
            {
              RRTNode4DPtr curr_node = (RRTNode4DPtr)kd_res_item_data(nbr_setA);
              neighbour_nodesA.nearing_nodes.emplace_back(curr_node, false, false);
              // store range query result so that we dont need to query again for rewire;
              kd_res_next(nbr_setA); // go to next in kd tree range query result
            }
          }
          kd_res_free(nbr_setA); // reset kd tree range query

          if (nbr_setB == nullptr) // TreeB
          {
            struct kdres *p_nearest = kd_nearest4(treeB, x_rand[0], x_rand[1], x_rand[2], x_rand[3]);
            if (p_nearest == nullptr)
            {
              ROS_ERROR("nearest query error");
              continue;
            }
            RRTNode4DPtr nearest_node = (RRTNode4DPtr)kd_res_item_data(p_nearest);
            kd_res_free(p_nearest);
            neighbour_nodesB.nearing_nodes.emplace_back(nearest_node, false, false);
          }
          else
          {
            check_connect = true;
            while (!kd_res_end(nbr_setB))
            {
              RRTNode4DPtr curr_node = (RRTNode4DPtr)kd_res_item_data(nbr_setB);
              neighbour_nodesB.nearing_nodes.emplace_back(curr_node, false, false);
              // store range query result so that we dont need to query again for rewire;
              kd_res_next(nbr_setB); // go to next in kd tree range query result
            }
          }
          kd_res_free(nbr_setB); // reset kd tree range query

          /* Sort two neighbor sets */
          sortNbrSet(neighbour_nodesA, x_rand);
          sortNbrSet(neighbour_nodesB, x_rand);

          /* Select the best parent tree */
          RRTNode4DPtr min_node_A(nullptr), min_node_B(nullptr);
          double min_cost_start_A(DBL_MAX), min_cost_start_B(DBL_MAX);
          double cost_parent_A(DBL_MAX), cost_parent_B(DBL_MAX);

          for (auto &curr_node : neighbour_nodesA.nearing_nodes)
          {
            curr_node.is_checked = true;
            if (map_ptr_->isSegCollisionFree(toMap(curr_node.node_ptr->x), toMap(x_rand), des_form_))
            {
              curr_node.is_valid = true;
              min_node_A = curr_node.node_ptr;
              cost_parent_A = calDist(min_node_A->x, x_rand);
              min_cost_start_A = min_node_A->cost_from_start + cost_parent_A;
              break;
            }
            else
            {
              curr_node.is_valid = false;
              continue;
            }
          }

          for (auto &curr_node : neighbour_nodesB.nearing_nodes)
          {
            curr_node.is_checked = true;
            if (map_ptr_->isSegCollisionFree(toMap(curr_node.node_ptr->x), toMap(x_rand), des_form_))
            {
              curr_node.is_valid = true;
              min_node_B = curr_node.node_ptr;
              cost_parent_B = calDist(min_node_B->x, x_rand);
              min_cost_start_B = min_node_B->cost_from_start + cost_parent_B;
              break;
            }
            else
            {
              curr_node.is_valid = false;
              continue;
            }
          }

          /* Insert new node and rewire the selected tree */
          RRTNode4DPtr new_node(nullptr);
          if ((min_node_A != nullptr) || (min_node_B != nullptr))
          {
            if (min_cost_start_A < min_cost_start_B)
            {
              // Sampling rejection
              if (min_cost_start_A + calDist(x_rand, goal_node_->x) >= cost_best_)
              {
                continue;
              }
              isTreeA = true;
              new_node = addTreeNode(min_node_A, x_rand, min_cost_start_A, cost_parent_A);
              kd_insert4(treeA, x_rand[0], x_rand[1], x_rand[2], x_rand[3], new_node);
              rewireTree(neighbour_nodesA, new_node, goal_node_->x);
            }
            else
            {
              if (min_cost_start_B + calDist(x_rand, start_node_->x) >= cost_best_)
              {
                continue;
              }
              isTreeA = false;
              new_node = addTreeNode(min_node_B, x_rand, min_cost_start_B, cost_parent_B);
              kd_insert4(treeB, x_rand[0], x_rand[1], x_rand[2], x_rand[3], new_node);
              rewireTree(neighbour_nodesB, new_node, start_node_->x);
            }
          }
          if ((min_node_A == nullptr) || (min_node_B == nullptr))
            check_connect = false;

          /* Check connection */
          if (check_connect)
          {
            double cost_curr = min_cost_start_A + min_cost_start_B;
            if (cost_curr < cost_best_)
            {
              cost_best_ = cost_curr;
              tree_connected = true;
              vector<Eigen::Vector4d> curr_best_path;
              if (isTreeA)
                fillPath(new_node, min_node_B, curr_best_path);
              else
                fillPath(min_node_A, new_node, curr_best_path);
              path_list_.emplace_back(curr_best_path);
              solution_cost_time_pair_list_.emplace_back(cost_best_, (ros::Time::now() - rrt_start_time).toSec());

              /* Update informed set */
              scale_[0] = cost_best_ / 2.0;
              scale_[1] = sqrt(scale_[0] * scale_[0] - c_square);
              scale_[3] = scale_[2] = scale_[1];
              sampler_.setInformedSacling(scale_);
              // std::vector<visualization::ELLIPSOID> ellps;
              // ellps.emplace_back(trans_, scale_, rot_);
              // vis_ptr_->visualize_ellipsoids(ellps, "informed_set", visualization::yellow, 0.2);
            }
          } /* End of brrt_star */
        }   /* End of brrt or brrt_star selection */
      }     /* End of one sampling iteration */

      if (tree_connected)
      {
        final_path_use_time_ = (ros::Time::now() - rrt_start_time).toSec();
        ROS_INFO_STREAM("[BRRT_Hype]: find_path_use_time: " << solution_cost_time_pair_list_.front().second << ", length: " << solution_cost_time_pair_list_.front().first);
        ROS_INFO_STREAM("[BRRT_Hype]: Time Cost: " << final_path_use_time_ << ", Final length: " << solution_cost_time_pair_list_.back().first << ", SampleNum: " << valid_tree_node_nums_);
        // visualizeWholeTree();
        final_path_ = path_list_.back();
        first_path_ = path_list_.front();
        visualizeFinalPath();
      }
      else if (valid_tree_node_nums_ == max_tree_node_nums_)
      {
        // visualizeWholeTree();
        ROS_ERROR_STREAM("[BRRT_Hype]: NOT CONNECTED TO GOAL after " << max_tree_node_nums_ << " nodes added to rrt-tree");
      }
      else
      {
        ROS_ERROR_STREAM("[BRRT_Hype]: NOT CONNECTED TO GOAL after " << (ros::Time::now() - rrt_start_time).toSec() << " seconds");
      }
      for (int k = 0; k < final_path_.size(); k++)
      {
        std::cout << "rotor::" << final_path_[k](2) << std::endl;
        std::cout << "scale::" << final_path_[k](3) << std::endl;
      }
      return tree_connected;
    }

    void visualizeWholeTree()
    {
      // Sample and visualize the resultant tree
      vector<Eigen::Vector4d> vertice;
      vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>> edges;
      vertice.clear();
      edges.clear();
      sampleWholeTree(start_node_, vertice, edges);
      sampleWholeTree(goal_node_, vertice, edges);
      std::vector<visualization::BALL> tree_balls;
      std::vector<visualization::BALL> tree_nodes;
      tree_balls.reserve(vertice.size());
      tree_nodes.reserve(vertice.size());
      visualization::BALL ball_p, node_p;
      node_p.radius = 0.12;
      for (size_t i = 0; i < vertice.size(); ++i)
      {
        node_p.center = vertice[i].head<3>();
        // node_p.center(2) = 1.0;
        tree_nodes.push_back(node_p);

        ball_p.center = node_p.center;
        ball_p.radius = 2 * vertice[i](3) / scale_weight_;
        tree_balls.push_back(ball_p);
      }
      vis_ptr_->visualize_balls(tree_balls, "tree_balls", visualization::Color::gray, 0.06);
      vis_ptr_->visualize_balls(tree_nodes, "tree_nodes", visualization::Color::black, 1.0);
      vis_ptr_->visualize_pairline(edges, "tree_edges", visualization::Color::steelblue, 0.07);
    }

    void visualizeFinalPath()
    {
      std::vector<visualization::BALL> path_nodes;
      vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>> path_edges;
      vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>> path_trajs;

      // formation
      std::vector<Eigen::Vector3d> form;
      // std::vector<int> adj_in = {0,0,0,0,0,0,1,2,3,4,5,6};
      // std::vector<int> adj_out = {1,2,3,4,5,6,2,3,4,5,6,1};
      std::vector<int> adj_in = {
          0,
          0,
          0,
          1,
          1,
          2,
          4,
      };
      std::vector<int> adj_out = {1, 2, 4, 3, 5, 3, 5};

      path_nodes.reserve(final_path_.size() * des_form_.size());
      path_edges.reserve(final_path_.size() * adj_in.size());
      path_trajs.reserve(final_path_.size() - 1);

      visualization::BALL ball_p;
      Eigen::Vector3d pos, pos_prev, pos_plus, pos_traj;
      pos_traj = {1, 0, 0};
      double scale;
      double x_des;
      double y_des;
      double r_des;
      ball_p.radius = 0.25;
      for (size_t i = 0; i < final_path_.size(); i++)
      {
        form.clear();
        pos = final_path_[i].head<3>();
        pos(2) = 1.0;
        r_des = final_path_[i](2);
        scale = final_path_[i](3) / scale_weight_;
        for (auto node : des_form_)
        {
          // x_des = scale * (cos(r_des) * node(0) + sin(r_des) * node(1));
          // y_des = scale * (-sin(r_des) * node(0) + cos(r_des) * node(1));
          x_des = scale*node(0);
          y_des = scale*node(1);
          pos_plus(0) = x_des;
          pos_plus(1) = y_des;
          pos_plus(2) = scale*node(2);
          ball_p.center = pos + pos_plus;
          path_nodes.push_back(ball_p);
          form.push_back(ball_p.center);
        }

        for (size_t j = 0; j < adj_in.size(); j++)
          path_edges.emplace_back(form[adj_in[j]], form[adj_out[j]]);
         
        if(i>=1){
        path_trajs.emplace_back(pos , pos_prev);
        }
        pos_prev = pos;
        // if (i >= 1)
        // {
        //   // path_trajs.emplace_back(pos + Eigen::Vector3d::Ones() * scale, pos_prev);
        // // pos_prev = pos + Eigen::Vector3d::Ones() * scale;

        // }
      }

      vis_ptr_->visualize_balls(path_nodes, "path_nodes", visualization::Color::purple, 1.2);
      vis_ptr_->visualize_pairline(path_edges, "path_edges", visualization::Color::blue, 0.1);
      vis_ptr_->visualize_pairline(path_trajs, "path_trajs", visualization::Color::red, 0.25);
    }

    void sampleWholeTree(const RRTNode4DPtr &root, vector<Eigen::Vector4d> &vertice, vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>> &edges)
    {
      if (root == nullptr)
        return;

      // whatever dfs or bfs
      Eigen::Vector3d n1, n2;
      RRTNode4DPtr node = root;
      std::queue<RRTNode4DPtr> Q;
      Q.push(node);
      while (!Q.empty())
      {
        node = Q.front();
        Q.pop();
        for (const auto &leafptr : node->children)
        {
          vertice.push_back(leafptr->x);
          n1 = node->x.head<3>();
          n2 = leafptr->x.head<3>();
          edges.emplace_back(std::make_pair(n1, n2));
          Q.push(leafptr);
        }
      }
    }

    void calInformedSet(double a2, const Eigen::Vector4d &foci1, const Eigen::Vector4d &foci2,
                        Eigen::Vector4d &scale, Eigen::Vector4d &trans, Eigen::Matrix4d &rot)
    {
      trans = (foci1 + foci2) / 2.0;
      scale[0] = a2 / 2.0;
      Eigen::Vector4d diff(foci2 - foci1);
      double c_square = diff.squaredNorm() / 4.0;
      scale[1] = sqrt(scale[0] * scale[0] - c_square);
      scale[3] = scale[2] = scale[1];
      // rot.col(0) = diff.normalized();
      // diff[2] = 0.0;
      // rot.col(1) = Eigen::AngleAxisd(0.5 * M_PI, Eigen::Vector3d::UnitZ()) * diff.normalized(); // project to the x-y plane and then rotate 90 degree;
      // rot.col(2) = rot.col(0).cross(rot.col(1));
      Eigen::Vector4d a1 = (foci2 - foci1) / calDist(foci1, foci2);
      Eigen::Matrix4d M = a1 * Eigen::MatrixXd::Identity(1, 4);
      Eigen::JacobiSVD<Eigen::Matrix4d> svd(M, Eigen::ComputeFullU | Eigen::ComputeFullV);
      Eigen::Vector4d diag_v(1.0, 1.0, svd.matrixU().determinant(), svd.matrixV().determinant());
      rot = svd.matrixU() * diag_v.asDiagonal() * svd.matrixV().transpose();
    }

    Eigen::Vector4d toMap(const Eigen::Vector4d &x)
    {
      Eigen::Vector4d xp = x.cwiseProduct(weight_inv_);
      return xp;
    }

    Eigen::Vector4d toSpace(const Eigen::Vector4d &x)
    {
      Eigen::Vector4d xp = x.cwiseProduct(weight_vec_);
      return xp;
    }

  public:
    void samplingOnce(Eigen::Vector3d &sample)
    {
      static int i = 0;
      sample = preserved_samples_[i];
      i++;
      i = i % preserved_samples_.size();
    }

    void setPreserveSamples(const vector<Eigen::Vector3d> &samples)
    {
      preserved_samples_ = samples;
    }
    vector<Eigen::Vector3d> preserved_samples_;
  };

} // namespace path_plan
#endif