#ifndef _REBO_REPLAN_FSM_H_
#define _REBO_REPLAN_FSM_H_

#include <Eigen/Eigen>
#include <algorithm>
#include <iostream>
#include <nav_msgs/Path.h>
#include <sensor_msgs/Imu.h>
#include <ros/ros.h>
#include <std_msgs/Empty.h>
#include <std_msgs/Bool.h>
#include <vector>
#include <visualization_msgs/Marker.h>

#include <optimizer/poly_traj_optimizer.h>
#include <plan_env/grid_map.h>
#include <geometry_msgs/PoseStamped.h>
#include <traj_utils/DataDisp.h>
#include <plan_manage/planner_manager.h>
#include <traj_utils/planning_visualization.h>
#include <traj_utils/PolyTraj.h>
#include <traj_utils/LocalGoal.h>
#include <traj_utils/RemapLocalGoalList.h>
#include <traj_utils/SwarmGlobalPathList.h>

#include <fstream>

using std::vector;

namespace ego_planner
{

  class EGOReplanFSM
  {

  private:
    /* ---------- flag ---------- */
    enum FSM_EXEC_STATE
    {
      INIT,
      WAIT_TARGET,
      GEN_NEW_TRAJ,
      REPLAN_TRAJ,
      EXEC_TRAJ,
      EMERGENCY_STOP,
      SEQUENTIAL_START
    };
    enum TARGET_TYPE
    {
      MANUAL_TARGET = 1,
      PRESET_TARGET = 2,
      SWARM_MANUAL_TARGET = 3,
      SWARM_PRESET_TARGET = 4,
      GLOBAL_PLANNER_TARGET = 5
    };
    enum CENTRAL_FSM_STATE
    {
      INIT_2,
      CHECK,
      CA_REMAP_ASSIGNMENT,
      SE_REMAP_ASSIGNMENT,
      REPLAN_GLOBAL_TRAJ,
      EXEC_ASSIGNMENT
    };

    /* planning utils */
    EGOPlannerManager::Ptr planner_manager_;
    PlanningVisualization::Ptr visualization_;
    traj_utils::DataDisp data_disp_;

    /* parameters */
    int target_type_; // in current version it's 3 (1 mannual select, 2 hard code)
    double no_replan_thresh_, replan_thresh_;
    double waypoints_[50][3];
    int waypoint_num_;
    double planning_horizen_max_, planning_horizen_min_, planning_horizen_, planning_horizen_time_;
    double emergency_time_;
    bool flag_realworld_experiment_;
    bool enable_fail_safe_;
    int last_end_id_;
    double formation_error_clearance_, aware_clearance_, softmax_aware_clearance_;
    double ca_delta_t_;
    double replan_trajectory_time_;//the max time of replanning trajectory(s)

    // global goal setting for swarm
    Eigen::Vector3d swarm_central_pos_;
    double swarm_scale_;
    double swarm_relative_pts_[50][3];
    std::vector<Eigen::Vector4d> swarm_global_path_;

    /* planning data */
    bool have_trigger_, have_target_, have_odom_, have_new_target_, have_recv_pre_agent_, have_local_goal_near_target_, have_local_traj_;
    FSM_EXEC_STATE exec_state_;
    CENTRAL_FSM_STATE central_state_;
    int continously_called_times_{0};

    Eigen::Vector3d odom_pos_, odom_vel_, odom_acc_; // odometry state
    Eigen::Quaterniond odom_orient_;                 // odometry oriention

    Eigen::Vector3d init_pt_, start_pt_, start_vel_, start_acc_, start_yaw_; // start state
    Eigen::Vector3d end_pt_, end_vel_;                                       // goal state
    Eigen::Vector3d local_target_pt_, local_target_vel_;                     // local target state
    int current_wp_;

    bool flag_escape_emergency_;
    bool flag_relan_astar_;
    bool isuse_local_vel_;

    vector<Eigen::Vector3d> remap_lg_pos_, remap_lg_vel_;
    Eigen::VectorXi assignment_;

    GlobalTrajData frontend_traj_;

    /* ROS utils */
    ros::NodeHandle node_;
    ros::Timer exec_timer_, safety_timer_, centra_timer_;
    ros::Subscriber waypoint_sub_, odom_sub_, swarm_trajs_sub_, broadcast_bspline_sub_, trigger_sub_, assignment_sub_;
    ros::Subscriber swarm_formation_waypoint_sub_, swarm_formation_trigger_sub_;
    ros::Publisher replan_pub_, new_pub_, poly_traj_pub_, data_disp_pub_, swarm_trajs_pub_, broadcast_bspline_pub_;
    ros::Publisher broadcast_ploytraj_pub_, broadcast_localgoal_pub_, broadcast_remaplocalgoal_pub_, broadcast_swarmglobalpath_pub_;
    ros::Subscriber broadcast_ploytraj_sub_, broadcast_localgoal_sub_, broadcast_remaplocalgoal_sub_, broadcast_swarmglobalpath_sub_;
    ros::Publisher reached_pub_, start_pub_;

    /* helper functions */
    bool callReboundReplan(bool flag_use_poly_init, bool use_formation); // front-end and back-end method
    bool callEmergencyStop(Eigen::Vector3d stop_pos);                    // front-end and back-end method
    bool callGlobalTrajReplan();
    bool callCARemapCheck();
    bool callSERemapCheck();
    bool planFromGlobalTraj(const int trial_times = 1);
    bool planFromLocalTraj(bool flag_use_poly_init, bool use_formation);

    /* return value: std::pair< Times of the same state be continuously called, current continuously called state > */
    void changeFSMExecState(FSM_EXEC_STATE new_state, string pos_call);
    void changeFSMCentralState(CENTRAL_FSM_STATE new_state, string pos_call);
    void printFSMExecState();
    void printFSMCentralState();
    std::pair<int, EGOReplanFSM::FSM_EXEC_STATE> timesOfConsecutiveStateCalls();
    bool callCALocalGoalRemap(vector<Eigen::Vector3d> &remap_lg_pos,
                              vector<Eigen::Vector3d> &remap_lg_vel,
                              Eigen::VectorXi &assignment);
    bool callSELocalGoalRemap(vector<Eigen::Vector3d> &remap_lg_pos,
                              vector<Eigen::Vector3d> &remap_lg_vel,
                              Eigen::VectorXi &assignment);

    void planGlobalTrajbyGivenWps();

    /* ROS functions */
    void setGlobalGoal(ros::NodeHandle &nh);
    void execFSMCallback(const ros::TimerEvent &e);
    void checkCollisionCallback(const ros::TimerEvent &e);
    void centralFSMCallback(const ros::TimerEvent &e);

    void waypointCallback(const geometry_msgs::PoseStampedPtr &msg);
    void formationWaypointCallback(const geometry_msgs::PoseStampedPtr &msg);
    void triggerCallback(const geometry_msgs::PoseStampedPtr &msg);
    void odometryCallback(const nav_msgs::OdometryConstPtr &msg);
    void RecvBroadcastPolyTrajCallback(const traj_utils::PolyTrajConstPtr &msg);
    void RecvBroadcastLocalGoalCallback(const traj_utils::LocalGoalConstPtr &msg);
    void RecvBroadcastRemapLocalGoalCallback(const traj_utils::RemapLocalGoalListConstPtr &msg);
    void RecvBroadcastSwarmGlobalPathCallback(const traj_utils::SwarmGlobalPathListConstPtr &msg);
    void polyTraj2ROSMsg(traj_utils::PolyTraj &msg);
    void localGoal2ROSMsg(traj_utils::LocalGoal &msg);
    void remapLocalGoalList2ROSMsg(traj_utils::RemapLocalGoalList &msg);

    bool frontEndPathSearching();
    bool checkCollision();

  public:
    EGOReplanFSM(/* args */)
    {
    }
    ~EGOReplanFSM();
    //-----------------------------------------------ztr debug-------------------------------
    std::ofstream log_ztr2;
    long int index{0};
    //-----------------------------------------------ztr debug-------------------------------
    void init(ros::NodeHandle &nh);

    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
  };

} // namespace ego_planner

#endif