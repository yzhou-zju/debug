/*
Copyright (C) 2022 Hongkai Ye (kyle_yeh@163.com)
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/
#ifndef FORM_RRT_STAR_H
#define FORM_RRT_STAR_H

#include "plan_env/grid_map.h"
#include "visualization.hpp"
#include "samplerto.h"
#include "node.h"
#include "kdtree.h"

#include <ros/ros.h>
#include <utility>
#include <queue>

namespace path_plan
{
  class FormRRTStar
  {
  public:
    FormRRTStar(){};
    FormRRTStar(const ros::NodeHandle &nh, const GridMap::Ptr &mapPtr, const vector<Eigen::Vector3d> &des_form) : nh_(nh), map_ptr_(mapPtr), des_form_(des_form)
    {
      nh_.param("RRT_Star/steer_length", steer_length_, 0.0);
      nh_.param("RRT_Star/search_radius", search_radius_, 0.0);
      nh_.param("RRT_Star/search_time", search_time_, 0.0);
      nh_.param("RRT_Star/max_tree_node_nums", max_tree_node_nums_, 0);
      nh_.param("RRT_Star/scale_weight", scale_weight_, 1.0);
      nh_.param("RRT_Star/sampling_range_x", sampling_range_x_, 30.0);
      nh_.param("RRT_Star/sampling_range_y", sampling_range_y_, 30.0);
      nh_.param("RRT_Star/sampling_range_z", sampling_range_z_, 3.0);
      nh_.param("RRT_Star/sampling_range_roll", sampling_range_roll_, 3.0);
      nh_.param("RRT_Star/sampling_range_pitch", sampling_range_pitch_, 3.0);
      nh_.param("RRT_Star/sampling_range_yaw", sampling_range_yaw_, 3.0);
      nh_.param("RRT_Star/sampling_range_scale_min", sampling_range_scale_min_, 0.1);
      nh_.param("RRT_Star/sampling_range_scale_max", sampling_range_scale_max_, 2.0);

      ROS_WARN_STREAM("[RRT*] param: steer_length: " << steer_length_);
      ROS_WARN_STREAM("[RRT*] param: search_radius: " << search_radius_);
      ROS_WARN_STREAM("[RRT*] param: search_time: " << search_time_);
      ROS_WARN_STREAM("[RRT*] param: max_tree_node_nums: " << max_tree_node_nums_);
      // Set sampling range
      weight_vec_.resize(7);
      weight_inv_.resize(7);
      weight_vec_ << 1.0, 1.0, 1.0, scale_weight_,1.0, 1.0 ,1.0;
      weight_inv_ << 1.0, 1.0, 1.0, 1.0 / scale_weight_, 1.0, 1.0, 1.0;
      Eigen::VectorXd sampling_origin;
      Eigen::VectorXd sampling_range;
      sampling_range.resize(7);
      sampling_origin.resize(7);
      sampling_origin <<-sampling_range_x_ / 2, -sampling_range_y_ / 2, 0.0, sampling_range_scale_min_,0,0,0;
      sampling_range <<sampling_range_x_, sampling_range_y_, sampling_range_z_, (sampling_range_scale_max_ - sampling_range_scale_min_),  sampling_range_yaw_,  sampling_range_pitch_,  sampling_range_roll_;
      sampler_.setSamplingRange(sampling_origin.cwiseProduct(weight_vec_), sampling_range.cwiseProduct(weight_vec_));

      valid_tree_node_nums_ = 0;
      nodes_pool_.resize(max_tree_node_nums_);
      for (int i = 0; i < max_tree_node_nums_; ++i)
      {
        nodes_pool_[i] = new TreeNode;
      }
    }
    ~FormRRTStar(){};

    bool plan(const Eigen::Vector4d &s, const Eigen::Vector4d &g)
    {
      reset();
      Eigen::VectorXd start;
      Eigen::VectorXd goal;
      start.resize(7);
      goal.resize(7);
      start << s(0),s(1),s(2),s(3),0,0,0;
      goal << g(0),g(1),g(2),g(3),0,0,0;

      Eigen::VectorXd start2;
      Eigen::VectorXd goal2;
      start2.resize(7);
      goal2.resize(7);
      start2 << s(0),s(1),s(2),s(3),0,0,0;
      goal2 << g(0),g(1),g(2),g(3),0,0,0;
      // start = s.cwiseProduct(weight_vec_);
      // goal = g.cwiseProduct(weight_vec_);

      if (!map_ptr_->isLeaderCollisionFree(start2, des_form_,true))
      {
        ROS_ERROR("[RRT*]: Start pos collide or out of ");
        return false;
      }
      if (!map_ptr_->isLeaderCollisionFree(goal2, des_form_,true))
      {
        ROS_ERROR("[RRT*]: Goal pos collide or out of bound");
        return false;
      }
      /* construct start and goal nodes */
      start_node_ = nodes_pool_[1]; // address of mem assign to ptr
      start_node_->x = start;
      start_node_->cost_from_start = 0.0;
      goal_node_ = nodes_pool_[0];
      goal_node_->x = goal;
      goal_node_->cost_from_start = DBL_MAX; // important
      valid_tree_node_nums_ = 2;             // put start and goal in tree

      ROS_INFO("[RRT*]: RRT starts planning a path");
      sampler_.reset(); // !important
      return rrt_star(start, goal);
    }

    vector<Eigen::VectorXd> getPath()
    {
      auto real_path = final_path_;
      for (size_t i = 0; i < final_path_.size(); i++)
      {
        real_path[i][3] /= scale_weight_;
      }

      return real_path;
      // return final_path_;
    }

    vector<vector<Eigen::VectorXd>> getAllPaths()
    {
      return path_list_;
    }

    vector<std::pair<double, double>> getSolutions()
    {
      return solution_cost_time_pair_list_;
    }

    void setVisualizer(const std::shared_ptr<visualization::Visualization> &visPtr)
    {
      vis_ptr_ = visPtr;
    };

    EIGEN_MAKE_ALIGNED_OPERATOR_NEW;

  private:
    // nodehandle params
    ros::NodeHandle nh_;

    BiasSamplerto sampler_;

    double steer_length_;
    double search_radius_;
    double search_time_;
    int max_tree_node_nums_;
    int valid_tree_node_nums_;
    double first_path_use_time_;
    double final_path_use_time_;
    double scale_weight_;

    Eigen::VectorXd weight_vec_;
    Eigen::VectorXd weight_inv_;

    // Formation template
    vector<Eigen::Vector3d> des_form_;
    // Sampling Range
    double sampling_range_x_, sampling_range_y_, sampling_range_z_, sampling_range_roll_, sampling_range_pitch_, sampling_range_yaw_;
    double sampling_range_scale_min_, sampling_range_scale_max_;

    std::vector<TreeNode *> nodes_pool_;
    TreeNode *start_node_;
    TreeNode *goal_node_;
    vector<Eigen::VectorXd> final_path_;
    vector<vector<Eigen::VectorXd>> path_list_;
    vector<std::pair<double, double>> solution_cost_time_pair_list_;

    // environment
    GridMap::Ptr map_ptr_;
    std::shared_ptr<visualization::Visualization> vis_ptr_;

    void reset()
    {
      final_path_.clear();
      path_list_.clear();
      solution_cost_time_pair_list_.clear();
      for (int i = 0; i < valid_tree_node_nums_; i++)
      {
        nodes_pool_[i]->parent = nullptr;
        nodes_pool_[i]->children.clear();
      }
      valid_tree_node_nums_ = 0;
    }

    double calDist(const Eigen::VectorXd &p1, const Eigen::VectorXd &p2)
    {
      return (p1 - p2).norm();
    }

    Eigen::VectorXd steer(const Eigen::VectorXd &nearest_node_p, const Eigen::VectorXd &rand_node_p)
    {
      Eigen::VectorXd diff_vec;
      diff_vec.resize(7);
      diff_vec = rand_node_p - nearest_node_p;
      double dist = diff_vec.norm();
      if (diff_vec.norm() <= steer_length_)
        return rand_node_p;
      else
        return nearest_node_p + diff_vec * steer_length_ / dist;
    }

    RRTNode4DPtr addTreeNode(RRTNode4DPtr &parent, const Eigen::VectorXd &state,
                             const double &cost_from_start, const double &cost_from_parent)
    {
      RRTNode4DPtr new_node_ptr = nodes_pool_[valid_tree_node_nums_];
      valid_tree_node_nums_++;
      new_node_ptr->parent = parent;
      parent->children.push_back(new_node_ptr);
      new_node_ptr->x = state;
      new_node_ptr->cost_from_start = cost_from_start;
      new_node_ptr->cost_from_parent = cost_from_parent;
      return new_node_ptr;
    }

    void changeNodeParent(RRTNode4DPtr &node, RRTNode4DPtr &parent, const double &cost_from_parent)
    {
      if (node->parent)
        node->parent->children.remove(node); // DON'T FORGET THIS, remove it form its parent's children list
      node->parent = parent;
      node->cost_from_parent = cost_from_parent;
      node->cost_from_start = parent->cost_from_start + cost_from_parent;
      parent->children.push_back(node);

      // for all its descedants, change the cost_from_start and tau_from_start;
      RRTNode4DPtr descendant(node);
      std::queue<RRTNode4DPtr> Q;
      Q.push(descendant);
      while (!Q.empty())
      {
        descendant = Q.front();
        Q.pop();
        for (const auto &leafptr : descendant->children)
        {
          leafptr->cost_from_start = leafptr->cost_from_parent + descendant->cost_from_start;
          Q.push(leafptr);
        }
      }
    }

    void fillPath(const RRTNode4DPtr &n, vector<Eigen::VectorXd> &path)
    {
      path.clear();
      RRTNode4DPtr node_ptr = n;
      while (node_ptr->parent)
      {
        path.push_back(node_ptr->x);
        node_ptr = node_ptr->parent;
      }
      path.push_back(start_node_->x);
      std::reverse(std::begin(path), std::end(path));
    }

    bool rrt_star(const Eigen::VectorXd &s, const Eigen::VectorXd &g)
    {
      ros::Time rrt_start_time = ros::Time::now();
      bool goal_found = false;

      /* kd tree init */
      kdtree *kd_tree = kd_create(3);
      // Add start and goal nodes to kd tree
      kd_insert7(kd_tree, start_node_->x[0], start_node_->x[1], start_node_->x[2], start_node_->x[3],start_node_->x[4], start_node_->x[5], start_node_->x[6],  start_node_);

      /* main loop */
      int idx = 0;
      for (idx = 0; (ros::Time::now() - rrt_start_time).toSec() < search_time_ && valid_tree_node_nums_ < max_tree_node_nums_; ++idx)
      {
        /* biased random sampling */
        Eigen::VectorXd x_rand;
        x_rand.resize(7);
        sampler_.samplingOnce(x_rand);

        if (!map_ptr_->isLeaderCollisionFree(x_rand.cwiseProduct(weight_inv_), des_form_,false))
        {
          continue;
        }

        struct kdres *p_nearest = kd_nearest7(kd_tree, x_rand[0], x_rand[1], x_rand[2], x_rand[3], x_rand[4], x_rand[5], x_rand[6]);
        if (p_nearest == nullptr)
        {
          ROS_ERROR("nearest query error");
          continue;
        }
        RRTNode4DPtr nearest_node = (RRTNode4DPtr)kd_res_item_data(p_nearest);
        kd_res_free(p_nearest);
         
        Eigen::VectorXd x_new;
        x_new.resize(7); 
        x_new = steer(nearest_node->x, x_rand);
        if (!map_ptr_->isSegCollisionFree(nearest_node->x.cwiseProduct(weight_inv_), x_new.cwiseProduct(weight_inv_), des_form_))
        {
          continue;
        }

        /* 1. find parent */
        /* kd_tree bounds search for parent */
        Neighbour neighbour_nodes;
        neighbour_nodes.nearing_nodes.reserve(50);
        neighbour_nodes.center = x_new;
        struct kdres *nbr_set;
        nbr_set = kd_nearest_range7(kd_tree, x_new[0], x_new[1], x_new[2], x_new[3], x_new[4], x_new[5], x_new[6], search_radius_);
        if (nbr_set == nullptr)
        {
          ROS_ERROR("bkwd kd range query error");
          break;
        }
        while (!kd_res_end(nbr_set))
        {
          RRTNode4DPtr curr_node = (RRTNode4DPtr)kd_res_item_data(nbr_set);
          neighbour_nodes.nearing_nodes.emplace_back(curr_node, false, false);
          // store range query result so that we dont need to query again for rewire;
          kd_res_next(nbr_set); // go to next in kd tree range query result
        }
        kd_res_free(nbr_set); // reset kd tree range query

        /* choose parent from kd tree range query result*/
        double dist2nearest = calDist(nearest_node->x, x_new);
        double min_dist_from_start(nearest_node->cost_from_start + dist2nearest);
        double cost_from_p(dist2nearest);
        RRTNode4DPtr min_node(nearest_node); // set the nearest_node as the default parent
        for (auto &curr_node : neighbour_nodes.nearing_nodes)
        {
          if (curr_node.node_ptr == nearest_node) // the nearest_node already calculated and checked collision free
          {
            continue;
          }

          // check potential first, then check edge collision
          double curr_dist = calDist(curr_node.node_ptr->x, x_new);
          double potential_dist_from_start = curr_node.node_ptr->cost_from_start + curr_dist;
          if (min_dist_from_start > potential_dist_from_start)
          {
            bool connected = map_ptr_->isSegCollisionFree(curr_node.node_ptr->x.cwiseProduct(weight_inv_), x_new.cwiseProduct(weight_inv_), des_form_);
            curr_node.is_checked = true;
            if (connected)
            {
              curr_node.is_valid = true;
              cost_from_p = curr_dist;
              min_dist_from_start = potential_dist_from_start;
              min_node = curr_node.node_ptr;
            }
          }
        }

        /* parent found within radius, then add a node to rrt and kd_tree */
        // sample-rejection
        double dist_to_goal = calDist(x_new, goal_node_->x);
        if (min_dist_from_start + dist_to_goal >= goal_node_->cost_from_start)
        {
          // ROS_WARN("parent found but sample rejected");
          continue;
        }

        /* 1.1 add the randomly sampled node to rrt_tree */
        RRTNode4DPtr new_node(nullptr);
        new_node = addTreeNode(min_node, x_new, min_dist_from_start, cost_from_p);

        /* 1.2 add the randomly sampled node to kd_tree */
        kd_insert7(kd_tree, x_new[0], x_new[1], x_new[2], x_new[3], x_new[4], x_new[5], x_new[6], new_node);
        // end of find parent

        /* 2. try to connect to goal if possible */
        if (dist_to_goal <= search_radius_)
        {
          bool is_connected2goal = map_ptr_->isSegCollisionFree(x_new.cwiseProduct(weight_inv_), goal_node_->x.cwiseProduct(weight_inv_), des_form_);
          // this test can be omitted if sample-rejction is applied
          bool is_better_path = goal_node_->cost_from_start > dist_to_goal + new_node->cost_from_start;
          if (is_connected2goal && is_better_path)
          {
            if (!goal_found)
            {
              first_path_use_time_ = (ros::Time::now() - rrt_start_time).toSec();
            }
            goal_found = true;
            changeNodeParent(goal_node_, new_node, dist_to_goal);
            vector<Eigen::VectorXd> curr_best_path;
            fillPath(goal_node_, curr_best_path);
            path_list_.emplace_back(curr_best_path);
            solution_cost_time_pair_list_.emplace_back(goal_node_->cost_from_start, (ros::Time::now() - rrt_start_time).toSec());
            // vis_ptr_->visualize_path(curr_best_path, "rrt_star_final_path");
            // vis_ptr_->visualize_pointcloud(curr_best_path, "rrt_star_final_wpts");
          }
        }

        /* 3.rewire */
        for (auto &curr_node : neighbour_nodes.nearing_nodes)
        {
          // new_node->x = x_new
          double dist_to_potential_child = calDist(new_node->x, curr_node.node_ptr->x);
          bool not_consistent = new_node->cost_from_start + dist_to_potential_child < curr_node.node_ptr->cost_from_start ? 1 : 0;
          bool promising = new_node->cost_from_start + dist_to_potential_child + calDist(curr_node.node_ptr->x, goal_node_->x) < goal_node_->cost_from_start ? 1 : 0;
          if (not_consistent && promising)
          {
            bool connected(false);
            if (curr_node.is_checked)
              connected = curr_node.is_valid;
            else
              connected = map_ptr_->isSegCollisionFree(new_node->x.cwiseProduct(weight_inv_), curr_node.node_ptr->x.cwiseProduct(weight_inv_), des_form_);

            // If we can get to a node via the sampled_node faster than via it's existing parent then change the parent
            if (connected)
            {
              double best_cost_before_rewire = goal_node_->cost_from_start;
              changeNodeParent(curr_node.node_ptr, new_node, dist_to_potential_child);
              if (best_cost_before_rewire > goal_node_->cost_from_start)
              {
                vector<Eigen::VectorXd> curr_best_path;
                fillPath(goal_node_, curr_best_path);
                path_list_.emplace_back(curr_best_path);
                solution_cost_time_pair_list_.emplace_back(goal_node_->cost_from_start, (ros::Time::now() - rrt_start_time).toSec());
                // vis_ptr_->visualize_path(curr_best_path, "rrt_star_final_path");
                // vis_ptr_->visualize_pointcloud(curr_best_path, "rrt_star_final_wpts");
              }
            }
          }
          /* go to the next entry */
        }
        /* end of rewire */
      }
      /* end of sample once */

      if (goal_found)
      {
        final_path_use_time_ = (ros::Time::now() - rrt_start_time).toSec();
        fillPath(goal_node_, final_path_);
        ROS_INFO_STREAM("[RRT*]: Time cost " << (ros::Time::now() - rrt_start_time).toSec() << ", Final Cost: " << goal_node_->cost_from_start << ", SampleNum: " << valid_tree_node_nums_);

        visualizeWholeTree();
        visualizeFinalPath();
      }
      else if (valid_tree_node_nums_ == max_tree_node_nums_)
      {
        ROS_ERROR_STREAM("[RRT*]: NOT CONNECTED TO GOAL after " << max_tree_node_nums_ << " nodes added to rrt-tree");
        visualizeWholeTree();
      }
      else
      {
        ROS_ERROR_STREAM("[RRT*]: NOT CONNECTED TO GOAL after " << (ros::Time::now() - rrt_start_time).toSec() << " seconds");
      }
      return goal_found;
    }

    void sampleWholeTree(const RRTNode4DPtr &root, vector<Eigen::VectorXd> &vertice, vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>> &edges)
    {
      if (root == nullptr)
        return;

      // whatever dfs or bfs
      Eigen::Vector3d n1, n2;
      RRTNode4DPtr node = root;
      std::queue<RRTNode4DPtr> Q;
      Q.push(node);
      while (!Q.empty())
      {
        node = Q.front();
        Q.pop();
        for (const auto &leafptr : node->children)
        {
          vertice.push_back(leafptr->x);
          n1 = node->x.head<3>();
          n2 = leafptr->x.head<3>();
          edges.emplace_back(std::make_pair(n1, n2));
          Q.push(leafptr);
        }
      }
    }

    void visualizeWholeTree()
    {
      // Sample and visualize the resultant tree
      vector<Eigen::VectorXd> vertice;
      vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>> edges;
      sampleWholeTree(start_node_, vertice, edges);
      std::vector<visualization::BALL> tree_balls;
      std::vector<visualization::BALL> tree_nodes;
      tree_balls.reserve(vertice.size());
      tree_nodes.reserve(vertice.size());
      visualization::BALL ball_p, node_p;
      node_p.radius = 0.12;
      for (size_t i = 0; i < vertice.size(); ++i)
      {
        node_p.center = vertice[i].head<3>();
        tree_nodes.push_back(node_p);

        ball_p.center = node_p.center;
        ball_p.radius = 2 * vertice[i](3) / scale_weight_;
        tree_balls.push_back(ball_p);
      }
      vis_ptr_->visualize_balls(tree_balls, "tree_balls", visualization::Color::gray, 0.06);
      vis_ptr_->visualize_balls(tree_nodes, "tree_nodes", visualization::Color::black, 1.0);
      vis_ptr_->visualize_pairline(edges, "tree_edges", visualization::Color::steelblue, 0.07);
    }

    void visualizeFinalPath()
    {
      std::vector<visualization::BALL> path_balls;
      visualization::BALL ball_p;
      path_balls.reserve(final_path_.size());
      for (size_t i = 0; i < final_path_.size(); i++)
      {
        ball_p.center = final_path_[i].head<3>();
        ball_p.radius = 2 * final_path_[i](3) / scale_weight_;
        path_balls.push_back(ball_p);
      }
      vis_ptr_->visualize_balls(path_balls, "path_balls", visualization::Color::purple, 0.8);
    }

  public:
    void samplingOnce(Eigen::Vector3d &sample)
    {
      static int i = 0;
      sample = preserved_samples_[i];
      i++;
      i = i % preserved_samples_.size();
    }

    void setPreserveSamples(const vector<Eigen::Vector3d> &samples)
    {
      preserved_samples_ = samples;
    }
    vector<Eigen::Vector3d> preserved_samples_;
  };

} // namespace path_plan
#endif