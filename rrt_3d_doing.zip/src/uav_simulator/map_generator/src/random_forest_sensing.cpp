#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
// #include <pcl/search/kdtree.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl_conversions/pcl_conversions.h>
#include <iostream>

#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Vector3.h>
#include <math.h>
#include <nav_msgs/Odometry.h>
#include <ros/console.h>
#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <Eigen/Eigen>
#include <random>
#include "traj_utils/GlbObsRcv.h"

using namespace std;

// pcl::search::KdTree<pcl::PointXYZ> kdtreeLocalMap;
pcl::KdTreeFLANN<pcl::PointXYZ> kdtreeLocalMap;
vector<int> pointIdxRadiusSearch;
vector<float> pointRadiusSquaredDistance;

random_device rd;
// default_random_engine eng(4);
default_random_engine eng;
uniform_real_distribution<double> rand_x;
uniform_real_distribution<double> rand_y;
uniform_real_distribution<double> rand_w;
uniform_real_distribution<double> rand_h;
uniform_real_distribution<double> rand_inf;

ros::Publisher _local_map_pub;
ros::Publisher _all_map_pub;
ros::Publisher click_map_pub_;
ros::Subscriber _odom_sub;

vector<double> _state;

int _obs_num;
double _x_size, _y_size, _z_size;
double _x_l, _x_h, _y_l, _y_h, _w_l, _w_h, _h_l, _h_h;
double _z_limit, _sensing_range, _resolution, _pub_rate;
double _min_dist;
int fix_obs_type_;


double x1h,x2h,x3h,x4h,x5h,x6h;
double x1l,x2l,x3l,x4l,x5l,x6l;
double y1l_,y2l,y3l,y4l,y5l,y6l;
double y1h,y2h,y3h,y4h,y5h,y6h;
bool _map_ok = false;
bool _has_odom = false;

int circle_num_;
double radius_l_, radius_h_, z_l_, z_h_;
double theta_;
uniform_real_distribution<double> rand_radius_;
uniform_real_distribution<double> rand_radius2_;
uniform_real_distribution<double> rand_theta_;
uniform_real_distribution<double> rand_z_;

sensor_msgs::PointCloud2 globalMap_pcd;
pcl::PointCloud<pcl::PointXYZ> cloudMap;

sensor_msgs::PointCloud2 localMap_pcd;
pcl::PointCloud<pcl::PointXYZ> clicked_cloud_;

void GenerateWall(double x_l, double x_h, 
                  double y_l, double y_h, 
                  double z_l, double z_h, 
                  pcl::PointCloud<pcl::PointXYZ>& cloudMap){
  int x_num, y_num, z_num;
  x_num = ceil((x_h - x_l)/_resolution);
  y_num = ceil((y_h - y_l)/_resolution);
  z_num = ceil((z_h - z_l)/_resolution);
  pcl::PointXYZ pt;
  for (int i=0; i<x_num; i++)
    for (int j=0; j<y_num; j++)
      for (int k=0; k<z_num; k++){
        pt.x = x_l + i * _resolution;
        pt.y = y_l + j * _resolution;
        pt.z = z_l + k * _resolution;
        cloudMap.push_back(pt);
      }
}

void GenerateCylinder(double x_c, double y_c, 
                      double w_c, double h_c)
{ 
  // w_c = 2 * radius;
  pcl::PointXYZ pt;
    double x, y, w, h;
    x = x_c;
    y = y_c;
    w = w_c;
    h = h_c;

    x = floor(x / _resolution) * _resolution + _resolution / 2.0;
    y = floor(y / _resolution) * _resolution + _resolution / 2.0;

    int widNum = ceil(w / _resolution);
    double radius = w / 2;
    int heiNum = ceil(h / _resolution);

    for (int r = -widNum / 2.0; r < widNum / 2.0; r++)
    {
      for (int s = -widNum / 2.0; s < widNum / 2.0; s++)
      {
        for (int t = -10; t < heiNum; t++)
        {
          double temp_x = x + (r + 0.5) * _resolution + 1e-2;
          double temp_y = y + (s + 0.5) * _resolution + 1e-2;
          double temp_z = (t + 0.5) * _resolution + 1e-2;
          if ((Eigen::Vector2d(temp_x, temp_y) - Eigen::Vector2d(x, y)).norm() <= radius)
          {
            pt.x = temp_x;
            pt.y = temp_y;
            pt.z = temp_z;
            cloudMap.points.push_back(pt);
          }
        }
      }
    }
}
void RandomMapGenerate()
{
  pcl::PointXYZ pt_random;

  rand_x = uniform_real_distribution<double>(_x_l, _x_h);
  rand_y = uniform_real_distribution<double>(_y_l, _y_h);
  rand_w = uniform_real_distribution<double>(_w_l, _w_h);
  rand_h = uniform_real_distribution<double>(_h_l, _h_h);

  rand_radius_ = uniform_real_distribution<double>(radius_l_, radius_h_);
  rand_radius2_ = uniform_real_distribution<double>(radius_l_, 1.2);
  rand_theta_ = uniform_real_distribution<double>(-theta_, theta_);
  rand_z_ = uniform_real_distribution<double>(z_l_, z_h_);

  // generate polar obs
  for (int i = 0; i < _obs_num; i++)
  {
    double x, y, w, h;
    x = rand_x(eng);
    y = rand_y(eng);
    w = rand_w(eng);

    x = floor(x / _resolution) * _resolution + _resolution / 2.0;
    y = floor(y / _resolution) * _resolution + _resolution / 2.0;

    int widNum = ceil(w / _resolution);

    for (int r = -widNum / 2.0; r < widNum / 2.0; r++)
      for (int s = -widNum / 2.0; s < widNum / 2.0; s++)
      {
        h = rand_h(eng);
        int heiNum = ceil(h / _resolution);
        for (int t = -20; t < heiNum; t++)
        {
          pt_random.x = x + (r + 0.5) * _resolution + 1e-2;
          pt_random.y = y + (s + 0.5) * _resolution + 1e-2;
          pt_random.z = (t + 0.5) * _resolution + 1e-2;
          cloudMap.points.push_back(pt_random);
        }
      }
  }

  // generate circle obs
  for (int i = 0; i < circle_num_; ++i)
  {
    double x, y, z;
    x = rand_x(eng);
    y = rand_y(eng);
    z = rand_z_(eng);

    x = floor(x / _resolution) * _resolution + _resolution / 2.0;
    y = floor(y / _resolution) * _resolution + _resolution / 2.0;
    z = floor(z / _resolution) * _resolution + _resolution / 2.0;

    Eigen::Vector3d translate(x, y, z);

    double theta = rand_theta_(eng);
    Eigen::Matrix3d rotate;
    rotate << cos(theta), -sin(theta), 0.0, sin(theta), cos(theta), 0.0, 0, 0,
        1;

    double radius1 = rand_radius_(eng);
    double radius2 = rand_radius2_(eng);

    // draw a circle centered at (x,y,z)
    Eigen::Vector3d cpt;
    for (double angle = 0.0; angle < 6.282; angle += _resolution / 2)
    {
      cpt(0) = 0.0;
      cpt(1) = radius1 * cos(angle);
      cpt(2) = radius2 * sin(angle);

      // inflate
      Eigen::Vector3d cpt_if;
      for (int ifx = -0; ifx <= 0; ++ifx)
        for (int ify = -0; ify <= 0; ++ify)
          for (int ifz = -0; ifz <= 0; ++ifz)
          {
            cpt_if = cpt + Eigen::Vector3d(ifx * _resolution, ify * _resolution,
                                           ifz * _resolution);
            cpt_if = rotate * cpt_if + Eigen::Vector3d(x, y, z);
            pt_random.x = cpt_if(0);
            pt_random.y = cpt_if(1);
            pt_random.z = cpt_if(2);
            cloudMap.push_back(pt_random);
          }
    }
  }

  cloudMap.width = cloudMap.points.size();
  cloudMap.height = 1;
  cloudMap.is_dense = true;

  ROS_WARN("Finished generate random map ");

  kdtreeLocalMap.setInputCloud(cloudMap.makeShared());

  _map_ok = true;
}

void RandomMapGenerateCylinder()
{
  pcl::PointXYZ pt_random;

  vector<Eigen::Vector2d> obs_position;

  rand_x = uniform_real_distribution<double>(_x_l, _x_h);
  rand_y = uniform_real_distribution<double>(_y_l, _y_h);
  rand_w = uniform_real_distribution<double>(_w_l, _w_h);
  rand_h = uniform_real_distribution<double>(_h_l, _h_h);
  rand_inf = uniform_real_distribution<double>(0.5, 1.5);

  rand_radius_ = uniform_real_distribution<double>(radius_l_, radius_h_);
  rand_radius2_ = uniform_real_distribution<double>(radius_l_, 1.2);
  rand_theta_ = uniform_real_distribution<double>(-theta_, theta_);
  rand_z_ = uniform_real_distribution<double>(z_l_, z_h_);

  // generate polar obs
  for (int i = 0; i < _obs_num && ros::ok(); i++)
  {
    double x, y, w, h, inf;
    x = rand_x(eng);
    y = rand_y(eng);
    w = rand_w(eng);
    inf = rand_inf(eng);

    bool flag_continue = false;
    for (auto p : obs_position)//如果距离太近，新生成的障碍物不能用，重新生成
      if ((Eigen::Vector2d(x, y) - p).norm() < _min_dist /*metres*/)
      {
        i--;
        flag_continue = true;
        break;
      }
    if (flag_continue)
      continue;

    obs_position.push_back(Eigen::Vector2d(x, y));

    x = floor(x / _resolution) * _resolution + _resolution / 2.0;
    y = floor(y / _resolution) * _resolution + _resolution / 2.0;

    int widNum = ceil((w * inf) / _resolution);
    double radius = (w * inf) / 2;

    for (int r = -widNum / 2.0; r < widNum / 2.0; r++)
      for (int s = -widNum / 2.0; s < widNum / 2.0; s++)
      {
        h = rand_h(eng);
        int heiNum = ceil(h / _resolution);
        for (int t = -10; t < heiNum; t++)
        {
          double temp_x = x + (r + 0.5) * _resolution + 1e-2;
          double temp_y = y + (s + 0.5) * _resolution + 1e-2;
          double temp_z = (t + 0.5) * _resolution + 1e-2;
          if ((Eigen::Vector2d(temp_x, temp_y) - Eigen::Vector2d(x, y)).norm() <= radius)
          {
            pt_random.x = temp_x;
            pt_random.y = temp_y;
            pt_random.z = temp_z;
            cloudMap.points.push_back(pt_random);
          }
        }
      }
  }

  // generate circle obs
  for (int i = 0; i < circle_num_; ++i)
  {
    double x, y, z;
    x = rand_x(eng);
    y = rand_y(eng);
    z = rand_z_(eng);

    x = floor(x / _resolution) * _resolution + _resolution / 2.0;
    y = floor(y / _resolution) * _resolution + _resolution / 2.0;
    z = floor(z / _resolution) * _resolution + _resolution / 2.0;

    Eigen::Vector3d translate(x, y, z);

    double theta = rand_theta_(eng);
    Eigen::Matrix3d rotate;
    rotate << cos(theta), -sin(theta), 0.0, sin(theta), cos(theta), 0.0, 0, 0,
        1;

    double radius1 = rand_radius_(eng);
    double radius2 = rand_radius2_(eng);

    // draw a circle centered at (x,y,z)
    Eigen::Vector3d cpt;
    for (double angle = 0.0; angle < 6.282; angle += _resolution / 2)
    {
      cpt(0) = 0.0;
      cpt(1) = radius1 * cos(angle);
      cpt(2) = radius2 * sin(angle);

      // inflate
      Eigen::Vector3d cpt_if;
      for (int ifx = -0; ifx <= 0; ++ifx)
        for (int ify = -0; ify <= 0; ++ify)
          for (int ifz = -0; ifz <= 0; ++ifz)
          {
            cpt_if = cpt + Eigen::Vector3d(ifx * _resolution, ify * _resolution,
                                           ifz * _resolution);
            cpt_if = rotate * cpt_if + Eigen::Vector3d(x, y, z);
            pt_random.x = cpt_if(0);
            pt_random.y = cpt_if(1);
            pt_random.z = cpt_if(2);
            cloudMap.push_back(pt_random);
          }
    }
  }

  cloudMap.width = cloudMap.points.size();
  cloudMap.height = 1;
  cloudMap.is_dense = true;

  ROS_WARN("Finished generate random map ");

  kdtreeLocalMap.setInputCloud(cloudMap.makeShared());

  _map_ok = true;
}

void FixMapGenerate(){
 
  switch (fix_obs_type_)
  {
    case 0: // NONE_FIX
    {
      break;
    }
     case 7: //Test Case for formation RRT //ztr
    { 
      // Generate cylinders
      double x_cy, y_cy, w_cy, h_cy;
      x_cy = -3.0;
      y_cy = 1.0;
      w_cy = 6.0;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);

      x_cy = 3.5;
      y_cy = -2.4;
      w_cy = 2.7;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);

      // Generate cluttered obs
      x_cy = -11.0;
      y_cy = -7.5;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);

      x_cy = 8.0;
      y_cy = 1.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);

      x_cy = 1.0;
      y_cy = -6.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);

      x_cy = -7.0;
      y_cy = -5.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);

      x_cy = -3.0;
      y_cy = -4.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);

      x_cy = 4.0;
      y_cy = 4.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);

      x_cy = 9.0;
      y_cy = -8.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);
      
      x_cy = 6.0;
      y_cy = -5.5;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);

      x_cy = 1.0;
      y_cy = 4.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);

      // Generate blocks
      double x_l, x_h, y_l, y_h, z_l, z_h;
      x_l = -5.4;
      x_h = 1;
      y_l = 7;
      y_h = 15;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l,x_h,y_l,y_h,z_l,z_h,cloudMap);

      x_l = -3;
      x_h = 1;
      y_l = -15;
      y_h = -8;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l,x_h,y_l,y_h,z_l,z_h,cloudMap);

      x_l = 1;
      x_h = 5;
      y_l = -15;
      y_h = -9.5;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l,x_h,y_l,y_h,z_l,z_h,cloudMap);

      // Generate walls

      //y+ wall
      x_l = -15;
      x_h = 15;
      y_l = 15;
      y_h = 15.4;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l,x_h,y_l,y_h,z_l,z_h,cloudMap);

      //y- wall
      x_l = -15;
      x_h = 15;
      y_l = -15.4;
      y_h = -15;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l,x_h,y_l,y_h,z_l,z_h,cloudMap);

      //x+ wall
      x_l = 15;
      x_h = 15.4;
      y_l = -15.4;
      y_h = 15.5;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l,x_h,y_l,y_h,z_l,z_h,cloudMap);

      //x- wall
      x_l = -15.4;
      x_h = -15;
      y_l = -15.4;
      y_h = 15.5;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l,x_h,y_l,y_h,z_l,z_h,cloudMap);
      break;
    }
    case 1: // WALL_WITH_HOLE
    {
      double x_l, x_h, y_l, y_h, z_l, z_h;
      x_l = -3.2;
      x_h = 6.2;
      y_l = - _y_size / 2;
      y_h = -1.6;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l, x_h, y_l, y_h, z_l, z_h, cloudMap);
      x_l = -3.2;
      x_h = 6.2;
      y_l = 1.6;
      y_h = _y_size / 2;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l, x_h, y_l, y_h, z_l, z_h, cloudMap);
      break;
    }

    case 2: // WALL_WITHOUT_HOLE
    {
      double x_l, x_h, y_l, y_h, z_l, z_h;
      x_l = -10.5;
      x_h = -9.5;
      y_l = -2.0;
      y_h = 2.0;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l, x_h, y_l, y_h, z_l, z_h, cloudMap);
      break;
    }
case 6: //Test Case 6 for formation RRT: Lil square case
    { 
      // Generate cluttered obs
      double x_cy, y_cy, w_cy, h_cy;
      x_cy = 3.4;
      y_cy = 0.0;
      w_cy = 0.3;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);

      x_cy = 6.0;
      y_cy = -2;
      w_cy = 0.3;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);

      x_cy = 5.0;
      y_cy = 4.5;
      w_cy = 0.3;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);

      x_cy = 5.0;
      y_cy = -6;
      w_cy = 0.3;
      h_cy = _z_size;
      GenerateCylinder(x_cy,y_cy,w_cy,h_cy);


      // Generate blocks
      double x_l, x_h, y_l, y_h, z_l, z_h;
      x_l = -4.8;
      x_h = 2.1;
      y_l = -3.5;
      y_h = 3.5;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l,x_h,y_l,y_h,z_l,z_h,cloudMap);

      // Generate walls

      //y+ wall
      x_l = -8;
      x_h = 8;
      y_l = 8;
      y_h = 8.4;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l,x_h,y_l,y_h,z_l,z_h,cloudMap);

      //y- wall
      x_l = -8;
      x_h = 8;
      y_l = -8.4;
      y_h = -8;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l,x_h,y_l,y_h,z_l,z_h,cloudMap);

      //x+ wall
      x_l = 8;
      x_h = 8.4;
      y_l = -8.4;
      y_h = 8.5;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l,x_h,y_l,y_h,z_l,z_h,cloudMap);

      //x- wall
      x_l = -8.4;
      x_h = -8;
      y_l = -8.4;
      y_h = 8.5;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(x_l,x_h,y_l,y_h,z_l,z_h,cloudMap);
      break;



    }
    
    
    
    case 8: //Test Case for formation RRT //ztr
    { 
      // Generate cylinders
      double x_cy, y_cy, w_cy, h_cy;
      x_cy = -3.0;
      y_cy = 1.0;
      w_cy = 6.0;
      h_cy = _z_size;
      // GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = 3.5;
      y_cy = -2.4;
      w_cy = 2.7;
      h_cy = _z_size;
      // GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);
     
      x_cy = -3.0;
      y_cy = 4.8;
      w_cy = 2.7;
      h_cy = _z_size;
      // GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);
     
      x_cy = 1.3;
      y_cy = 0;
      w_cy = 2.3;
      h_cy = _z_size;
      // GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      // Generate cluttered obs
      x_cy = -11.0;
      y_cy = -7.5;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      // Generate cluttered obs
      x_cy = -20.0;
      y_cy = 1.5;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = 8.0;
      y_cy = 1.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = 1.0;
      y_cy = -6.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = -7.0;
      y_cy = -5.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = -3.0;
      y_cy = -4.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = 4.0;
      y_cy = 4.0;
      w_cy = 0.5;
      h_cy = _z_size;
     GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = 9.0;
      y_cy = -8.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);
      
      x_cy = 6.0;
      y_cy = -5.5;
      w_cy = 0.5;
      h_cy = _z_size;
  GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = 1.0;
      y_cy = 4.0;
      w_cy = 0.5;
      h_cy = _z_size;
   GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      // Generate blocks
      double x_l, x_h, y_l, y_h, z_l, z_h;
      x_l = -5.4;
      x_h = 1;
      y_l = 7;
      y_h = 15;
      z_l = -1.0;
      z_h = _z_size;
      // GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);

      x_l = -3;
      x_h = 1;
      y_l = -15;
      y_h = -8;
      z_l = -1.0;
      z_h = _z_size;
    // GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);
      x_l = 1;
      x_h = 5;
      y_l = -15;
      y_h = -9.5;
      z_l = -1.0;
      z_h = _z_size;
    // GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);

      // Generate walls

      //y+ wall
      x_l = -30;
      x_h = 30;
      y_l = 15;
      y_h = 15.4;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);

      //y- wall
      x_l = -30;
      x_h = 30;
      y_l = -15.4;
      y_h = -15;
      z_l = -1.0;
      z_h = _z_size;
         GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);

      //x+ wall
      x_l = 20;
      x_h = 20.4;
      y_l = -15.4;
      y_h = 15.5;
      z_l = -1.0;
      z_h = _z_size;
        //  GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);

      //x- wall
      x_l = -20.4;
      x_h = -20;
      y_l = -15.4;
      y_h = 15.5;
      z_l = -1.0;
      z_h = _z_size;
      //  GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);
      break;
    }


    case 9: //YLJ
    { 
      // Generate cylinders
      double x_cy, y_cy, w_cy, h_cy;
      x_cy = -3.0;
      y_cy = 1.0;
      w_cy = 6.0;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = 3.5;
      y_cy = -2.4;
      w_cy = 2.7;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);
     
      x_cy = -3.0;
      y_cy = 4.8;
      w_cy = 2.7;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);
     
      x_cy = 1.3;
      y_cy = 0;
      w_cy = 2.3;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      // Generate cluttered obs
      x_cy = -11.0;
      y_cy = -7.5;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = 8.0;
      y_cy = 1.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = 1.0;
      y_cy = -6.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = -7.0;
      y_cy = -5.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = -3.0;
      y_cy = -4.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = 4.0;
      y_cy = 4.0;
      w_cy = 0.5;
      h_cy = _z_size;
     GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = 9.0;
      y_cy = -8.0;
      w_cy = 0.5;
      h_cy = _z_size;
      GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);
      
      x_cy = 6.0;
      y_cy = -5.5;
      w_cy = 0.5;
      h_cy = _z_size;
  GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      x_cy = 1.0;
      y_cy = 4.0;
      w_cy = 0.5;
      h_cy = _z_size;
   GenerateCylinder(2*x_cy,2*y_cy,2*w_cy,2*h_cy);

      // Generate blocks
      double x_l, x_h, y_l, y_h, z_l, z_h;
      x_l = -5.4;
      x_h = 1;
      y_l = 7;
      y_h = 15;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);

      x_l = -3;
      x_h = 1;
      y_l = -15;
      y_h = -8;
      z_l = -1.0;
      z_h = _z_size;
    GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);
      x_l = 1;
      x_h = 5;
      y_l = -15;
      y_h = -9.5;
      z_l = -1.0;
      z_h = _z_size;
    GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);

      // Generate walls

      //y+ wall
      x_l = -15;
      x_h = 15;
      y_l = 15;
      y_h = 15.4;
      z_l = -1.0;
      z_h = _z_size;
      GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);

      //y- wall
      x_l = -15;
      x_h = 15;
      y_l = -15.4;
      y_h = -15;
      z_l = -1.0;
      z_h = _z_size;
         GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);

      //x+ wall
      x_l = 15;
      x_h = 15.4;
      y_l = -15.4;
      y_h = 15.5;
      z_l = -1.0;
      z_h = _z_size;
         GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);

      //x- wall
      x_l = -15.4;
      x_h = -15;
      y_l = -15.4;
      y_h = 15.5;
      z_l = -1.0;
      z_h = _z_size;
       GenerateWall(2*x_l,2*x_h,2*y_l,2*y_h,2*z_l,2*z_h,cloudMap);
      break;
    }
  }
 
  cloudMap.width = cloudMap.points.size();
  cloudMap.height = 1;
  cloudMap.is_dense = true;

  kdtreeLocalMap.setInputCloud(cloudMap.makeShared());
  _map_ok = true;
  ROS_WARN("Finished generate fixed map ");
}

void clickCallback(const geometry_msgs::PoseStamped &msg)
{
  double x = msg.pose.position.x;
  double y = msg.pose.position.y;
  double w = rand_w(eng);
  double h;
  pcl::PointXYZ pt_random;

  x = floor(x / _resolution) * _resolution + _resolution / 2.0;
  y = floor(y / _resolution) * _resolution + _resolution / 2.0;

  int widNum = ceil(w / _resolution);

  for (int r = -widNum / 2.0; r < widNum / 2.0; r++)
    for (int s = -widNum / 2.0; s < widNum / 2.0; s++)
    {
      h = rand_h(eng);
      int heiNum = ceil(h / _resolution);
      for (int t = -1; t < heiNum; t++)
      {
        pt_random.x = x + (r + 0.5) * _resolution + 1e-2;
        pt_random.y = y + (s + 0.5) * _resolution + 1e-2;
        pt_random.z = (t + 0.5) * _resolution + 1e-2;
        clicked_cloud_.points.push_back(pt_random);
        cloudMap.points.push_back(pt_random);
      }
    }
  clicked_cloud_.width = clicked_cloud_.points.size();
  clicked_cloud_.height = 1;
  clicked_cloud_.is_dense = true;

  pcl::toROSMsg(clicked_cloud_, localMap_pcd);
  localMap_pcd.header.frame_id = "world";
  click_map_pub_.publish(localMap_pcd);

  cloudMap.width = cloudMap.points.size();

  return;
}

int i = 0;
void pubPoints()
{
  while (ros::ok())
  {
    ros::spinOnce();
    if (_map_ok)
      break;
  }
  
  pcl::toROSMsg(cloudMap, globalMap_pcd);
  globalMap_pcd.header.frame_id = "world";
  _all_map_pub.publish(globalMap_pcd);
   ROS_INFO("Global PCL published.");
}

bool pubGlbObs(traj_utils::GlbObsRcv::Request &req, traj_utils::GlbObsRcv::Response &res)
{
   pubPoints();
   return true;
}


int main(int argc, char **argv)
{
  ros::init(argc, argv, "random_map_sensing");
  ros::NodeHandle n("~");

  _local_map_pub = n.advertise<sensor_msgs::PointCloud2>("/map_generator/local_cloud", 1);
  _all_map_pub = n.advertise<sensor_msgs::PointCloud2>("/map_generator/global_cloud", 1);
  
  click_map_pub_ =
      n.advertise<sensor_msgs::PointCloud2>("/pcl_render_node/local_map", 1);

  n.param("map/x_size", _x_size, 50.0);
  n.param("map/y_size", _y_size, 50.0);
  n.param("map/z_size", _z_size, 5.0);

  n.param("map/x1l", x1l, 50.0);
  n.param("map/x2l", x2l, 50.0);
  n.param("map/x3l", x3l, 50.0);
  n.param("map/x4l", x4l, 50.0);
  n.param("map/x5l", x5l, 50.0);
  n.param("map/x6l", x6l, 50.0);
  n.param("map/x1h", x1h, 50.0);
  n.param("map/x2h", x2h, 50.0);
  n.param("map/x3h", x3h, 50.0);
  n.param("map/x4h", x4h, 50.0);
  n.param("map/x5h", x5h, 50.0);
  n.param("map/x6h", x6h, 50.0);

  n.param("map/y1l", y1l_, 50.0);
  n.param("map/y2l", y2l, 50.0);
  n.param("map/y3l", y3l, 50.0);
  n.param("map/y4l", y4l, 50.0);
  n.param("map/y5l", y5l, 50.0);
  n.param("map/y6l", y6l, 50.0);
  n.param("map/y1h", y1h, 50.0);
  n.param("map/y2h", y2h, 50.0);
  n.param("map/y3h", y3h, 50.0);
  n.param("map/y4h", y4h, 50.0);
  n.param("map/y5h", y5h, 50.0);
  n.param("map/y6h", y6h, 50.0);




  n.param("map/obs_num", _obs_num, 30);//obs_num and circle num
  n.param("map/resolution", _resolution, 0.1);
  n.param("map/circle_num", circle_num_, 30);

  n.param("ObstacleShape/lower_rad", _w_l, 0.3);
  n.param("ObstacleShape/upper_rad", _w_h, 0.8);
  n.param("ObstacleShape/lower_hei", _h_l, 3.0);
  n.param("ObstacleShape/upper_hei", _h_h, 7.0);

  n.param("ObstacleShape/radius_l", radius_l_, 7.0);
  n.param("ObstacleShape/radius_h", radius_h_, 7.0);
  n.param("ObstacleShape/z_l", z_l_, 7.0);
  n.param("ObstacleShape/z_h", z_h_, 7.0);
  n.param("ObstacleShape/theta", theta_, 7.0);
  n.param("fix_obs_type", fix_obs_type_, 0);

  n.param("pub_rate", _pub_rate, 10.0);
  n.param("min_distance", _min_dist, 1.0);

  _x_l = -_x_size / 2.0;
  _x_h = +_x_size / 2.0;

  _y_l = -_y_size / 2.0;
  _y_h = +_y_size / 2.0;

  _obs_num = min(_obs_num, (int)_x_size * 10);
  _z_limit = _z_size;
  
  ros::Duration(0.5).sleep();
  
  // unsigned int seed = rd();
  unsigned int seed = 3587752923; // only for test
  // unsigned int seed = 3423482073;  // quanlun: 04-07
  // unsigned int seed = 1238785342;  // quanlun: 04-06

  cout << "seed = " << seed << " ~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~~!~" << endl;
  eng.seed(seed);
  
  // RandomMapGenerate();  wait to debug
  RandomMapGenerateCylinder();
  FixMapGenerate();
  cout << "x1l = " << x1l<< endl;
  cout << "x1h = " << x1h<< endl;
  cout << "y1l_ = " << y1l_<< endl;
  cout << "y1h = " << y1h<< endl;
  cout << "x2l = " << x2l<< endl;
  cout << "x2h = " << x2h<< endl;
  cout << "y2l_ = " << y2l<< endl;
  cout << "y2h = " << y2h<< endl;
  GenerateWall(x1l,x1h,y1l_,y1h,0,6,cloudMap);
  GenerateWall(x2l,x2h,y2l,y2h,0,6,cloudMap);
  GenerateWall(x3l,x3h,y3l,y3h,0,6,cloudMap);
  GenerateWall(x4l,x4h,y4l,y4h,0,6,cloudMap);
  GenerateWall(x5l,x5h,y5l,y5h,0,6,cloudMap);
  GenerateWall(x6l,x6h,y6l,y6h,0,6,cloudMap);

  ros::Rate loop_rate(_pub_rate);

ros::ServiceServer pub_glb_obs_service = n.advertiseService("/pub_glb_obs", pubGlbObs);
  // only for vrb benchmark
  // int i=0;
  while (ros::ok())
  {
    if (i<5){
      pubPoints();
      i++;
    }
    ros::spinOnce();
    loop_rate.sleep();
  }
}
